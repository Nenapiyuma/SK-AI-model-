import React, { useState } from 'react';
import { SystemStatusResponse } from '../types/skai';
import { CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';

interface RegistryAndHardwareProps {
  statusData: SystemStatusResponse | null;
  darkMode: boolean;
  onRefresh: () => void;
}

export const RegistryAndHardware: React.FC<RegistryAndHardwareProps> = ({
  statusData,
  darkMode,
  onRefresh,
}) => {
  const [evalData, setEvalData] = useState<Record<string, any> | null>(null);
  const [runningEval, setRunningEval] = useState(false);

  const runEvaluationSuite = async () => {
    setRunningEval(true);
    try {
      const res = await fetch('/api/skai/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (data.ok) setEvalData(data.result);
    } finally {
      setRunningEval(false);
    }
  };

  const surfaceCls = darkMode
    ? 'bg-slate-900 border-slate-800 text-slate-100'
    : 'bg-white border-slate-200 text-slate-900';

  if (!statusData) {
    return (
      <div className="py-12 text-center text-sm text-slate-500">
        Loading SK AI Model Registry, SHA-256 Verifier, and Hardware Telemetry...
      </div>
    );
  }

  const { hardware, storage, smoke, quantization_comparison } = statusData;

  return (
    <div className="space-y-8">
      {/* Section 1: Hardware Telemetry */}
      <div className={`p-6 rounded-xl border ${surfaceCls} space-y-4`}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold tracking-tight">04. Live Hardware &amp; 1 TB Storage Architecture</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Real-time host inspection via hardware/detect.py and scripts/storage_report.py (zero fabricated metrics).
            </p>
          </div>
          <button
            onClick={onRefresh}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Telemetry</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-2 border-t border-slate-200 dark:border-slate-800 font-mono tabular-nums text-xs">
          <div>
            <p className="text-slate-500 font-sans font-medium">CPU &amp; Architecture</p>
            <p className="text-sm font-semibold mt-1">{hardware.cpu.logical_cores} Logical Cores ({hardware.cpu.architecture})</p>
            <p className="text-slate-400 truncate mt-0.5">{hardware.cpu.model_name}</p>
          </div>
          <div>
            <p className="text-slate-500 font-sans font-medium">System RAM</p>
            <p className="text-sm font-semibold mt-1">
              {hardware.memory.available_gb} GB Free / {hardware.memory.total_gb} GB Total
            </p>
            <p className="text-slate-400 mt-0.5">Used: {hardware.memory.used_gb} GB ({hardware.memory.percent_used}%)</p>
          </div>
          <div>
            <p className="text-slate-500 font-sans font-medium">GPU &amp; Acceleration</p>
            <p className="text-sm font-semibold mt-1">
              {hardware.gpu.supported_acceleration} ({hardware.gpu.gpu_count} GPU)
            </p>
            <p className="text-slate-400 mt-0.5">Detected VRAM: {hardware.gpu.total_vram_gb} GB</p>
          </div>
          <div>
            <p className="text-slate-500 font-sans font-medium">Model Storage Summary</p>
            <p className="text-sm font-semibold text-emerald-500 mt-1">
              Installed: {storage.total_installed_formatted}
            </p>
            <p className="text-slate-400 mt-0.5">
              Library Catalog: {storage.total_available_library_formatted} / 1.00 TB Budget
            </p>
          </div>
        </div>
      </div>

      {/* Section 2: Model Registry Table */}
      <div className={`p-6 rounded-xl border ${surfaceCls} space-y-4`}>
        <div>
          <h3 className="text-base font-semibold">SK AI Model Registry (models/registry.json)</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Distinguishes BUILT BY SK AI vs THIRD-PARTY MODEL and verifies real on-disk byte sizes and SHA-256 hashes.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2.5 pr-4 font-medium">Component</th>
                <th className="py-2.5 px-3 font-medium">Origin</th>
                <th className="py-2.5 px-3 font-medium text-right">Parameters</th>
                <th className="py-2.5 px-3 font-medium">Quant</th>
                <th className="py-2.5 px-3 font-medium">Size on Disk / Library</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 pl-3 font-medium">License · SHA-256 Prefix</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/60 dark:divide-slate-800/70 font-mono tabular-nums">
              {storage.rows.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-500/5">
                  <td className="py-2.5 pr-4 font-sans font-medium">{row.component}</td>
                  <td className="py-2.5 px-3 text-slate-500">{row.origin}</td>
                  <td className="py-2.5 px-3 text-right">{row.parameters.toLocaleString()}</td>
                  <td className="py-2.5 px-3">{row.quantization}</td>
                  <td className="py-2.5 px-3">{row.size_formatted}</td>
                  <td className="py-2.5 px-3">
                    {row.status === 'INSTALLED' ? (
                      <span className="text-emerald-500 font-semibold">INSTALLED</span>
                    ) : (
                      <span className="text-amber-500">NOT INSTALLED</span>
                    )}
                  </td>
                  <td className="py-2.5 pl-3 text-slate-400">
                    {row.license} {row.sha256 ? `· ${row.sha256.slice(0, 12)}…` : ''}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Section 3: Empirical Quantization Comparison & 16-Point Smoke Test */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className={`lg:col-span-6 p-6 rounded-xl border ${surfaceCls} space-y-4`}>
          <div>
            <h3 className="text-base font-semibold">Empirical Weight Quantization Benchmark</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Measured via quantization/quantizer.py across FP32, FP16, BF16, INT8, and 4-bit blockwise quantization.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 font-sans">
                  <th className="py-2 pr-3">Format</th>
                  <th className="py-2 px-2 text-right">Bytes</th>
                  <th className="py-2 px-2 text-right">Ratio</th>
                  <th className="py-2 px-2 text-right">Measured MSE</th>
                  <th className="py-2 pl-2 text-right">SNR (dB)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/60 dark:divide-slate-800/70">
                {quantization_comparison.map((q) => (
                  <tr key={q.format}>
                    <td className="py-2 pr-3 font-semibold">{q.format}</td>
                    <td className="py-2 px-2 text-right">{q.quantized_size_bytes.toLocaleString()} B</td>
                    <td className="py-2 px-2 text-right">{q.compression_ratio}x</td>
                    <td className="py-2 px-2 text-right">{q.measured_mse}</td>
                    <td className="py-2 pl-2 text-right text-emerald-500">{q.measured_snr_db} dB</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold">Empirical Evaluation Suite (evaluation/suite.py)</h4>
              <button
                onClick={runEvaluationSuite}
                disabled={runningEval}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
              >
                {runningEval ? 'Running Benchmarks...' : 'Run Evaluation Suite'}
              </button>
            </div>
            {evalData && (
              <pre className="p-3 rounded-lg bg-slate-950 text-slate-200 text-xs font-mono overflow-x-auto max-h-48">
                {JSON.stringify(evalData.suites, null, 2)}
              </pre>
            )}
          </div>
        </div>

        <div className={`lg:col-span-6 p-6 rounded-xl border ${surfaceCls} space-y-4`}>
          <div>
            <h3 className="text-base font-semibold">16-Subsystem Smoke Verification (scripts/smoke_test.py)</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Core subsystems verified live; optional un-downloaded checkpoints reported honestly as NOT INSTALLED.
            </p>
          </div>
          <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1 text-xs font-mono tabular-nums">
            {smoke.core_checks.map((chk) => (
              <div
                key={chk.step}
                className="flex items-center justify-between py-1.5 border-b border-slate-200/50 dark:border-slate-800/60"
              >
                <div className="flex items-center gap-2">
                  {chk.status === 'PASS' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0" />
                  )}
                  <span className="font-sans font-medium">
                    {String(chk.step).padStart(2, '0')}. {chk.component}
                  </span>
                </div>
                <span className="text-emerald-500 font-semibold">{chk.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
