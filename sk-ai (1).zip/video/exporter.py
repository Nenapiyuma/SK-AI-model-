"""
SKVideoExporter: Saves generated video frame sequences and manifest metadata to disk.
"""

import os
import json
from typing import Dict, Any, List


class SKVideoExporter:
    @staticmethod
    def export_frame_sequence(
        frames: List[Dict[str, Any]],
        output_dir: str = "models/weights/video_frames",
        fps: int = 4,
    ) -> Dict[str, Any]:
        os.makedirs(output_dir, exist_ok=True)
        saved_paths: List[str] = []
        total_bytes = 0
        for f in frames:
            idx = f["frame_index"]
            p = os.path.join(output_dir, f"frame_{idx:03d}.png")
            with open(p, "wb") as fp:
                fp.write(f["png_bytes"])
            total_bytes += len(f["png_bytes"])
            saved_paths.append(p)

        manifest_path = os.path.join(output_dir, "video_manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as mf:
            json.dump({"frame_count": len(saved_paths), "fps": fps, "frames": saved_paths}, mf, indent=2)

        return {
            "output_dir": output_dir,
            "manifest_path": manifest_path,
            "frame_paths": saved_paths,
            "frame_count": len(saved_paths),
            "total_size_bytes": total_bytes,
            "frame_data_urls": [f["data_url"] for f in frames],
        }
