"""
SKMidiGenerator: Generates standard binary SMF (Standard MIDI File) `.mid` files
from SK-MUSIC symbolic compositions.
"""

import os
import struct
from typing import Dict, Any, List


def _encode_vlq(val: int) -> bytes:
    """Encode integer as Standard MIDI Variable-Length Quantity."""
    buffer = [val & 0x7F]
    val >>= 7
    while val > 0:
        buffer.append((val & 0x7F) | 0x80)
        val >>= 7
    return bytes(reversed(buffer))


class SKMidiGenerator:
    def write_midi(
        self,
        composition: Dict[str, Any],
        output_path: str = "models/weights/generated_music.mid",
    ) -> Dict[str, Any]:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        ticks_per_beat = 480
        track_events = bytearray()

        # Set tempo meta event (FF 51 03 tt tt tt)
        bpm = composition.get("tempo_bpm", 120)
        mpqn = int(60_000_000 / max(1, bpm))
        track_events.extend(b"\x00\xff\x51\x03" + struct.pack(">I", mpqn)[1:])

        # Add melody note_on and note_off events
        for note in composition.get("melody_notes", []):
            pitch = int(note["midi_note"]) & 0x7F
            vel = int(note.get("velocity", 90)) & 0x7F
            dur_ticks = max(60, int(ticks_per_beat * 0.5))
            # Note On at delta=0
            track_events.extend(_encode_vlq(0) + bytes([0x90, pitch, vel]))
            # Note Off after dur_ticks
            track_events.extend(_encode_vlq(dur_ticks) + bytes([0x80, pitch, 0]))

        # End of Track meta event (00 FF 2F 00)
        track_events.extend(b"\x00\xff\x2f\x00")

        mthd = b"MThd" + struct.pack(">IHhh", 6, 0, 1, ticks_per_beat)
        mtrk = b"MTrk" + struct.pack(">I", len(track_events)) + bytes(track_events)
        midi_bytes = mthd + mtrk

        with open(output_path, "wb") as f:
            f.write(midi_bytes)

        return {
            "midi_path": output_path,
            "file_size_bytes": len(midi_bytes),
            "tempo_bpm": bpm,
            "note_count": len(composition.get("melody_notes", [])),
        }
