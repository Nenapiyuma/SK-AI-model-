"""
SK AI Model Registry & Package Manager (`model_manager/`).
Manages local model checkpoints, dynamically verifies SHA-256 hashes and actual byte sizes,
tracks the 1 TB modular storage architecture, and distinguishes BUILT BY SK AI vs THIRD-PARTY MODEL.
"""

from .manager import SKModelManager

__all__ = ["SKModelManager"]
