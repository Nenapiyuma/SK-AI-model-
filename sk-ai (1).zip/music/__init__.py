"""
SK-MUSIC Subsystem (`music/`).
Supports original melody, harmony, rhythm, instrumentation, arrangement, Song-to-Arrangement
transformations, stem generation, MIDI export, and WAV audio synthesis with strict copyright guardrails.
"""

from .composer import SKMusicComposer
from .arranger import SKMusicArranger
from .midi_generator import SKMidiGenerator
from .audio_generator import SKMusicAudioGenerator
from .stems import SKStemProcessor
from .exporter import SKMusicExporter
from .music_model import SKMusicModel

__all__ = [
    "SKMusicComposer",
    "SKMusicArranger",
    "SKMidiGenerator",
    "SKMusicAudioGenerator",
    "SKStemProcessor",
    "SKMusicExporter",
    "SKMusicModel",
]
