"""
SK AI Empirical Evaluation Suite (`evaluation/`).
Executes real runtime verification across Sinhala, English, coding, reasoning, instruction following,
vision, image generation, music, and video, storing actual measured metrics in `benchmarks/results/`.
"""

from .suite import SKEvaluationSuite

__all__ = ["SKEvaluationSuite"]
