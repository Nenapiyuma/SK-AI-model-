"""
TextToImageGenerator: Generates PNG images from text prompts, negative prompts, resolution, seed, and guidance.
"""

import os
import base64
from typing import Dict, Any
from .conditioning import PromptConditioner
from .sampler import IterativeDiffusionSampler


class TextToImageGenerator:
    def __init__(self):
        self.conditioner = PromptConditioner()
        self.sampler = IterativeDiffusionSampler()

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 160,
        height: int = 160,
        steps: int = 12,
        guidance_scale: float = 7.5,
        seed: int = 42,
        output_path: str = "models/weights/generated_image.png",
    ) -> Dict[str, Any]:
        cond = self.conditioner.encode_prompt(prompt, negative_prompt=negative_prompt)
        png_bytes, meta = self.sampler.sample_rgb_grid(
            conditioning=cond,
            width=width,
            height=height,
            steps=steps,
            guidance_scale=guidance_scale,
            seed=seed,
        )
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(png_bytes)

        return {
            "subsystem": "SK-IMAGE",
            "mode": "text_to_image",
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "output_path": output_path,
            "file_size_bytes": len(png_bytes),
            "data_url": "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii"),
            **meta,
        }
