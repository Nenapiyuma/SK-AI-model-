"""
SKEmbeddingModel: Local Deterministic Bilingual (Sinhala + English) Dense Embedding Engine.
Uses character & token n-gram hashing projected through a learned/seeded orthogonal matrix
and L2-normalized to unit hypersphere for cosine similarity retrieval.
"""

import os
import math
import hashlib
from typing import List, Dict, Any
from model.tensor_backend import SKMatrix, compute_sha256_bytes


class SKEmbeddingModel:
    def __init__(self, dim: int = 64, bucket_size: int = 256):
        self.dim = dim
        self.bucket_size = bucket_size
        self.projection = SKMatrix(bucket_size, dim, seed=2026)

    def embed_text(self, text: str) -> List[float]:
        clean = text.strip().lower()
        if not clean:
            return [0.0] * self.dim

        buckets = [0.0] * self.bucket_size
        # Extract words and 3-character n-grams (works across both English ASCII and Sinhala Unicode)
        words = clean.split()
        tokens = list(words)
        for w in words:
            for i in range(max(1, len(w) - 2)):
                tokens.append(w[i : i + 3])

        for tok in tokens:
            h = int(hashlib.md5(tok.encode("utf-8")).hexdigest()[:8], 16)
            buckets[h % self.bucket_size] += 1.0

        dense = self.projection.vecmat(buckets)
        norm = math.sqrt(sum(v * v for v in dense)) or 1.0
        return [round(v / norm, 6) for v in dense]

    @staticmethod
    def cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
        if len(vec_a) != len(vec_b) or not vec_a:
            return 0.0
        dot = sum(a * b for a, b in zip(vec_a, vec_b))
        na = math.sqrt(sum(a * a for a in vec_a)) or 1.0
        nb = math.sqrt(sum(b * b for b in vec_b)) or 1.0
        return dot / (na * nb)

    def save_weights(self, filepath: str) -> Dict[str, Any]:
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        raw = self.projection.to_bytes()
        with open(filepath, "wb") as f:
            f.write(raw)
        return {
            "filepath": filepath,
            "file_size": len(raw),
            "sha256": compute_sha256_bytes(raw),
            "parameters": self.projection.numel,
        }
