"""
Supervised Fine-Tuning (SFT) & Instruction Tuning Pipeline for SK-LLM.
Computes loss strictly over assistant completion tokens while masking user prompt tokens.
"""

from typing import List, Dict, Any, Optional
from .pretrain import PretrainingPipeline


class SFTPipeline:
    """Instruction-tuning pipeline supporting Sinhala, English, and Coding instruction pairs."""

    def __init__(self, pretrainer: Optional[PretrainingPipeline] = None):
        self.pretrainer = pretrainer or PretrainingPipeline()

    def format_instruction_pair(self, instruction: str, response: str, system: str = "") -> Dict[str, Any]:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": instruction})
        prompt_str = self.pretrainer.tokenizer.apply_chat_template(messages)
        full_str = f"{prompt_str}{response}<|eos|>"
        prompt_ids = self.pretrainer.tokenizer.encode(prompt_str, add_special_tokens=False)
        full_ids = self.pretrainer.tokenizer.encode(full_str, add_special_tokens=False)
        labels = [-100] * len(prompt_ids) + full_ids[len(prompt_ids) :]
        return {
            "input_ids": full_ids,
            "labels": labels,
            "supervised_tokens": max(0, len(full_ids) - len(prompt_ids)),
        }

    def run_sft_step(self, pairs: List[Dict[str, str]], step: int = 0) -> Dict[str, Any]:
        texts = [f"<|user|>{p['instruction']}<|eos|><|assistant|>{p['response']}<|eos|>" for p in pairs]
        res = self.pretrainer.run_step(texts, step=step)
        res["mode"] = "sft_instruction_tuning"
        res["pairs_count"] = len(pairs)
        return res
