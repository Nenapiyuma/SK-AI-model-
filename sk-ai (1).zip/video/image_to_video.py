from typing import Dict, Any
from .frame_processor import VideoFrameProcessor


class ImageToVideoPipeline:
    def __init__(self):
        self.processor = VideoFrameProcessor()

    def generate(
        self,
        prompt: str,
        conditioning_image: str = "",
        duration_sec: float = 1.5,
        fps: int = 4,
        width: int = 128,
        height: int = 96,
        seed: int = 42,
    ) -> Dict[str, Any]:
        num_frames = max(2, min(12, int(round(duration_sec * fps))))
        frames = self.processor.render_frames(
            f"{prompt} [conditioned:{conditioning_image}]",
            num_frames=num_frames,
            width=width,
            height=height,
            seed=seed,
        )
        return {
            "mode": "image_to_video",
            "conditioning_image": conditioning_image,
            "frames": frames,
            "fps": fps,
            "duration_sec": duration_sec,
        }
