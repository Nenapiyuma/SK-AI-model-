"""
SK AI Hybrid Tensor Backend (PyTorch + Pure-Python Deterministic Tensor Engine).
Ensures SK AI models initialize, compute real mathematical forward passes, serialize weights,
and run inference on both GPU/PyTorch environments and standalone CPU environments.
"""

import math
import random
import struct
import hashlib
from array import array
from typing import List, Tuple, Optional, Dict, Any

try:
    import torch  # type: ignore
    HAS_TORCH = True
except ImportError:
    torch = None
    HAS_TORCH = False


def has_torch_backend() -> bool:
    return HAS_TORCH


class SKMatrix:
    """
    Lightweight 2D float32 matrix backed by Python's contiguous `array('f')` buffer.
    Used for real linear projections, embeddings, and attention computations when PyTorch is absent.
    """

    def __init__(self, rows: int, cols: int, data: Optional[array] = None, seed: Optional[int] = None):
        self.rows = rows
        self.cols = cols
        size = rows * cols
        if data is not None:
            if len(data) != size:
                raise ValueError(f"Data length {len(data)} does not match shape ({rows}, {cols})")
            self.data = data
        else:
            rng = random.Random(seed if seed is not None else 42)
            scale = 1.0 / math.sqrt(max(1, cols))
            self.data = array("f", (rng.gauss(0.0, scale) for _ in range(size)))

    @property
    def shape(self) -> Tuple[int, int]:
        return (self.rows, self.cols)

    @property
    def numel(self) -> int:
        return self.rows * self.cols

    def to_bytes(self) -> bytes:
        return self.data.tobytes()

    @classmethod
    def from_bytes(cls, rows: int, cols: int, raw: bytes) -> "SKMatrix":
        arr = array("f")
        arr.frombytes(raw[: rows * cols * 4])
        return cls(rows, cols, arr)

    def get_row(self, r: int) -> List[float]:
        start = r * self.cols
        return list(self.data[start : start + self.cols])

    def matvec(self, vec: List[float]) -> List[float]:
        """Multiply (rows x cols) matrix with (cols,) vector -> (rows,) vector."""
        out = [0.0] * self.rows
        cols = self.cols
        data = self.data
        for r in range(self.rows):
            offset = r * cols
            s = 0.0
            for c in range(cols):
                s += data[offset + c] * vec[c]
            out[r] = s
        return out

    def vecmat(self, vec: List[float]) -> List[float]:
        """Multiply (rows,) vector with (rows x cols) matrix -> (cols,) vector."""
        out = [0.0] * self.cols
        cols = self.cols
        data = self.data
        for r in range(self.rows):
            vr = vec[r]
            if vr == 0.0:
                continue
            offset = r * cols
            for c in range(cols):
                out[c] += vr * data[offset + c]
        return out


def rms_norm_vector(vec: List[float], weight: List[float], eps: float = 1e-6) -> List[float]:
    n = len(vec)
    if n == 0:
        return []
    mean_sq = sum(x * x for x in vec) / n
    inv_rms = 1.0 / math.sqrt(mean_sq + eps)
    return [vec[i] * inv_rms * weight[i] for i in range(n)]


def silu_vector(vec: List[float]) -> List[float]:
    out = [0.0] * len(vec)
    for i, x in enumerate(vec):
        val = max(-20.0, min(20.0, x))
        out[i] = x / (1.0 + math.exp(-val))
    return out


def softmax_vector(vec: List[float]) -> List[float]:
    if not vec:
        return []
    m = max(vec)
    exps = [math.exp(max(-50.0, x - m)) for x in vec]
    total = sum(exps) or 1.0
    return [e / total for e in exps]


def compute_sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
