"""
SKMemoryManager: Manages user-approved preferences, conversation memory, project memory,
and document RAG memory with strict user opt-in and deletion controls.
"""

from typing import Dict, Any, List, Optional
from .vector_store import SKVectorStore
from .retrieval import SKRetriever


class SKMemoryManager:
    def __init__(self, store_path: str = "memory/local_vectors.json", enabled: bool = True):
        self.enabled = enabled
        self.vector_store = SKVectorStore(store_path=store_path)
        self.retriever = SKRetriever(self.vector_store)

    def store_memory(
        self,
        text: str,
        category: str = "conversation",
        user_approved: bool = True,
    ) -> Dict[str, Any]:
        if not self.enabled or not user_approved:
            return {"stored": False, "reason": "Memory disabled or not approved by user."}
        rec = self.vector_store.add_record(text=text, category=category)
        return {"stored": True, "id": rec["id"], "category": category}

    def query_memory(self, query: str, top_k: int = 3, category: Optional[str] = None) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        return self.vector_store.search(query=query, top_k=top_k, category=category)

    def remove_memory(self, record_id: str) -> Dict[str, Any]:
        removed = self.vector_store.delete_record(record_id)
        return {"removed": removed, "id": record_id}

    def reset_all_memory(self) -> Dict[str, Any]:
        removed_count = self.vector_store.clear_all()
        return {"cleared": True, "records_removed": removed_count}
