"""
Unified SK AI Local Python API (`core/skai.py`).
Supports:
    from skai import SKAI
    ai = SKAI()
    response = ai.chat("Explain quantum computing in Sinhala.")
"""

from typing import Dict, Any, Optional
from .orchestrator import SKAIOrchestrator
from model_manager.manager import SKModelManager
from hardware.detect import HardwareDetector


class SKAI:
    """
    Primary Unified Python Interface for the SK AI Multimodal Ecosystem.
    """

    def __init__(self, workspace_root: str = ".", offline_mode: bool = True):
        self.workspace_root = workspace_root
        self.offline_mode = offline_mode
        self.model_manager = SKModelManager(workspace_root=workspace_root)
        self.orchestrator = SKAIOrchestrator(workspace_root=workspace_root, offline_mode=offline_mode)

    def chat(self, prompt: str) -> Dict[str, Any]:
        return self.orchestrator.execute_request(prompt=prompt)

    def generate_text(self, prompt: str, max_new_tokens: int = 64, temperature: float = 0.7) -> Dict[str, Any]:
        return self.orchestrator.llm_engine.generate(
            prompt=prompt, max_new_tokens=max_new_tokens, temperature=temperature
        )

    def generate_code(self, prompt: str, language: Optional[str] = None) -> Dict[str, Any]:
        return self.orchestrator.code_agent.handle_coding_task(prompt=prompt, language=language)

    def analyze_image(self, image_path: str, question: str = "Describe this image.") -> Dict[str, Any]:
        return self.orchestrator.vision_model.analyze_image(image_path=image_path, question=question)

    def generate_image(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 160,
        height: int = 160,
        steps: int = 12,
        guidance_scale: float = 7.5,
        seed: int = 42,
    ) -> Dict[str, Any]:
        return self.orchestrator.image_pipeline.run(
            prompt=prompt,
            negative_prompt=negative_prompt,
            width=width,
            height=height,
            steps=steps,
            guidance_scale=guidance_scale,
            seed=seed,
        )

    def generate_music(
        self,
        prompt: str,
        duration_sec: float = 3.5,
        transform_style: Optional[str] = None,
        tempo_multiplier: float = 1.0,
    ) -> Dict[str, Any]:
        return self.orchestrator.music_model.generate_music(
            prompt=prompt,
            duration_sec=duration_sec,
            transform_style=transform_style,
            tempo_multiplier=tempo_multiplier,
        )

    def generate_video(
        self,
        prompt: str,
        duration_sec: float = 1.5,
        fps: int = 4,
        width: int = 128,
        height: int = 96,
        seed: int = 42,
        mode: str = "text_to_video",
    ) -> Dict[str, Any]:
        return self.orchestrator.video_model.generate_video(
            prompt=prompt,
            duration_sec=duration_sec,
            fps=fps,
            width=width,
            height=height,
            seed=seed,
            mode=mode,
        )

    def transcribe_audio(self, audio_path: str) -> Dict[str, Any]:
        return self.orchestrator.speech_model.transcribe_audio(audio_path=audio_path)

    def synthesize_speech(self, text: str) -> Dict[str, Any]:
        return self.orchestrator.speech_model.synthesize_speech(text=text)

    def create_android_project(
        self,
        prompt: str = "Create a Sinhala AI chat app.",
        project_name: str = "SKAISinhalaChat",
        output_dir: str = "generated_projects/android_app",
    ) -> Dict[str, Any]:
        return self.orchestrator.android_gen.create_android_project(
            prompt=prompt, project_name=project_name, output_dir=output_dir
        )

    def create_windows_project(
        self,
        prompt: str = "Make this HTML app into a Windows EXE.",
        project_name: str = "SKAIDesktopApp",
        stack: Optional[str] = None,
        output_dir: str = "generated_projects/windows_exe",
    ) -> Dict[str, Any]:
        return self.orchestrator.windows_gen.create_windows_project(
            prompt=prompt, project_name=project_name, stack=stack, output_dir=output_dir
        )

    def get_hardware_status(self) -> Dict[str, Any]:
        return HardwareDetector.detect_all(self.workspace_root)
