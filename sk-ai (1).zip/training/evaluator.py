"""
Training Evaluator for SK-LLM checkpoints.
Computes real validation loss and perplexity on held-out Sinhala and English evaluation samples.
"""

from typing import List, Dict, Any
from .pretrain import PretrainingPipeline


class TrainingEvaluator:
    def __init__(self, pipeline: PretrainingPipeline):
        self.pipeline = pipeline

    def evaluate_corpus(self, validation_texts: List[str]) -> Dict[str, Any]:
        metrics = self.pipeline.run_step(validation_texts, step=0)
        return {
            "num_samples": len(validation_texts),
            "validation_loss": metrics["loss"],
            "validation_perplexity": metrics["perplexity"],
            "tokens_evaluated": metrics["tokens_processed"],
        }
