"""
AgentVerifier: Checks intermediate and final results for completeness, syntax validity,
and policy compliance before returning to the user.
"""

from typing import Dict, Any


class AgentVerifier:
    def verify(self, result: Dict[str, Any]) -> Dict[str, Any]:
        has_error = bool(result.get("error"))
        has_content = bool(
            result.get("text")
            or result.get("code")
            or result.get("output_path")
            or result.get("files_created")
            or result.get("status") == "completed"
        )
        return {
            "verified": (not has_error) and has_content,
            "has_error": has_error,
            "error_message": result.get("error"),
        }
