"""
SK AI Android App Development & Client Architecture (`android/`).
Generates complete Android Studio projects (Kotlin + Jetpack Compose + Gradle KTS + AndroidManifest)
supporting Dual-Mode execution:
- Mode A: Local On-Device SK AI Mini execution
- Mode B: Windows PC Local Area Network (LAN) server connection
"""

from .generator import SKAndroidGenerator

__all__ = ["SKAndroidGenerator"]
