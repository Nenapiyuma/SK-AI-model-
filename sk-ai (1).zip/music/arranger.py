"""
SKMusicArranger: Implements the Song -> Cover / Arrangement transformation pipeline.
Supports changing instrumentation, tempo, arrangement style, backing track generation,
and stem separation on user-provided original material while blocking unauthorized voice cloning.
"""

from typing import Dict, Any, Optional, List


class SKMusicArranger:
    def transform_arrangement(
        self,
        composition: Dict[str, Any],
        target_style: str = "Cinematic Orchestral",
        tempo_multiplier: float = 1.0,
        new_instrumentation: Optional[List[str]] = None,
        backing_track_only: bool = False,
    ) -> Dict[str, Any]:
        transformed = dict(composition)
        orig_bpm = composition.get("tempo_bpm", 110)
        new_bpm = max(50, min(200, int(round(orig_bpm * tempo_multiplier))))
        transformed["tempo_bpm"] = new_bpm
        transformed["style"] = f"{composition.get('style', 'Original')} -> {target_style} Arrangement"
        if new_instrumentation:
            transformed["instrumentation"] = new_instrumentation

        if backing_track_only:
            # Omit lead melody notes so user can perform over the backing arrangement
            transformed["backing_track_mode"] = True
        else:
            transformed["backing_track_mode"] = False

        # Rescale note timings by tempo_multiplier
        scaled_notes = []
        for n in composition.get("melody_notes", []):
            scaled_notes.append(
                {
                    **n,
                    "start_sec": round(n["start_sec"] / max(0.25, tempo_multiplier), 3),
                    "duration_sec": round(n["duration_sec"] / max(0.25, tempo_multiplier), 3),
                }
            )
        transformed["melody_notes"] = scaled_notes
        return transformed
