import React, { useState } from 'react';
import { Code2, Smartphone, Monitor, CheckCircle2 } from 'lucide-react';

interface ProjectBuildersProps {
  darkMode: boolean;
}

const LANGUAGES = [
  'Python', 'TypeScript', 'JavaScript', 'Kotlin', 'Rust', 'C++', 'C',
  'Java', 'Swift', 'SQL', 'HTML', 'CSS', 'Bash', 'PowerShell', 'JSON', 'YAML', 'XML',
];

export const ProjectBuilders: React.FC<ProjectBuildersProps> = ({ darkMode }) => {
  const [builderTab, setBuilderTab] = useState<'android' | 'windows' | 'code'>('android');
  const [loading, setLoading] = useState(false);

  // Android state
  const [androidPrompt, setAndroidPrompt] = useState('Create a Sinhala AI chat app.');
  const [androidName, setAndroidName] = useState('SKAISinhalaChat');
  const [androidResult, setAndroidResult] = useState<Record<string, any> | null>(null);
  const [selectedAndroidFile, setSelectedAndroidFile] = useState<string>('app/src/main/AndroidManifest.xml');

  // Windows state
  const [winPrompt, setWinPrompt] = useState('Make this HTML app into a Windows EXE.');
  const [winName, setWinName] = useState('SKAIDesktopApp');
  const [winStack, setWinStack] = useState('electron');
  const [winResult, setWinResult] = useState<Record<string, any> | null>(null);
  const [selectedWinFile, setSelectedWinFile] = useState<string>('README.md');

  // Code state
  const [codePrompt, setCodePrompt] = useState('Create a thread-safe tensor batch processor');
  const [codeLang, setCodeLang] = useState('Python');
  const [codeResult, setCodeResult] = useState<Record<string, any> | null>(null);

  const generateAndroid = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/android', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: androidPrompt, project_name: androidName }),
      });
      const data = await res.json();
      if (data.ok) {
        setAndroidResult(data.result);
        const firstFile = data.result.files_created?.[0] || 'README.md';
        setSelectedAndroidFile(firstFile);
      }
    } finally {
      setLoading(false);
    }
  };

  const generateWindows = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/windows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: winPrompt, project_name: winName, stack: winStack }),
      });
      const data = await res.json();
      if (data.ok) {
        setWinResult(data.result);
        setSelectedWinFile(data.result.files_created?.[0] || 'README.md');
      }
    } finally {
      setLoading(false);
    }
  };

  const generateCode = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: codePrompt, language: codeLang }),
      });
      const data = await res.json();
      if (data.ok) setCodeResult(data.result);
    } finally {
      setLoading(false);
    }
  };

  const surfaceCls = darkMode
    ? 'bg-slate-900 border-slate-800 text-slate-100'
    : 'bg-white border-slate-200 text-slate-900';
  const inputCls = darkMode
    ? 'bg-slate-950 border-slate-800 text-slate-100'
    : 'bg-slate-50 border-slate-300 text-slate-900';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">03. Android, Windows EXE &amp; 17-Language Code Builders</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Generate complete Android Studio (Kotlin/Jetpack Compose) projects, Windows desktop wrappers, and AST-verified source code.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          {[
            { id: 'android', label: 'Android Studio (Kotlin/Compose)', icon: Smartphone },
            { id: 'windows', label: 'Windows EXE Builder', icon: Monitor },
            { id: 'code', label: 'SK-CODE (17 Languages)', icon: Code2 },
          ].map((t) => {
            const Icon = t.icon;
            const active = builderTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setBuilderTab(t.id as any)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {builderTab === 'android' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-4 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Android Studio Project Specification</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Natural-Language App Request</label>
              <input
                type="text"
                value={androidPrompt}
                onChange={(e) => setAndroidPrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Project Name</label>
              <input
                type="text"
                value={androidName}
                onChange={(e) => setAndroidName(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border font-mono ${inputCls}`}
              />
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
              <p className="font-medium text-slate-700 dark:text-slate-300">Dual-Mode Client Architecture Included:</p>
              <p>· Mode A: Local On-Device SK AI Mini Execution</p>
              <p>· Mode B: Windows PC Local Network (LAN) Bridge</p>
            </div>
            <button
              onClick={generateAndroid}
              disabled={loading}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
            >
              {loading ? 'Generating Android Project...' : 'Generate Complete Android Project'}
            </button>
          </div>

          <div className={`lg:col-span-8 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Generated Android Studio Files &amp; Compose Source</h3>
            {!androidResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Click &ldquo;Generate Complete Android Project&rdquo; to write Gradle KTS, AndroidManifest.xml, strings.xml, and MainActivity.kt to disk.
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {androidResult.files_created?.map((file: string) => (
                    <button
                      key={file}
                      onClick={() => setSelectedAndroidFile(file)}
                      className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors ${
                        selectedAndroidFile === file
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'border-slate-300 dark:border-slate-700 text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      {file}
                    </button>
                  ))}
                </div>
                <pre className="p-4 rounded-lg bg-slate-950 text-slate-100 text-xs font-mono overflow-x-auto max-h-96 leading-relaxed">
                  {androidResult.files_preview?.[selectedAndroidFile] || ''}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {builderTab === 'windows' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-4 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Windows .EXE Desktop Builder</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Packaging Request</label>
              <input
                type="text"
                value={winPrompt}
                onChange={(e) => setWinPrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Target Wrapper Stack</label>
              <select
                value={winStack}
                onChange={(e) => setWinStack(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              >
                <option value="electron">Electron Desktop Wrapper (HTML/JS → .EXE)</option>
                <option value="python-pyinstaller">Python PyInstaller Standalone (.spec → .EXE)</option>
              </select>
            </div>
            <button
              onClick={generateWindows}
              disabled={loading}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
            >
              {loading ? 'Generating Windows Project...' : 'Generate Windows EXE Project'}
            </button>
          </div>

          <div className={`lg:col-span-8 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Generated Windows Project &amp; Build Environment Check</h3>
            {!winResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Click &ldquo;Generate Windows EXE Project&rdquo; to inspect the project structure and build validation status.
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                  <p className="font-semibold">Host Compiler Validation (Honest Build Reporting):</p>
                  <p className="text-slate-500 dark:text-slate-400">{winResult.build_environment_status}</p>
                  <p className="font-mono text-emerald-500">Build Command: {winResult.build_command}</p>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {winResult.files_created?.map((file: string) => (
                    <button
                      key={file}
                      onClick={() => setSelectedWinFile(file)}
                      className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors ${
                        selectedWinFile === file
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'border-slate-300 dark:border-slate-700 text-slate-500'
                      }`}
                    >
                      {file}
                    </button>
                  ))}
                </div>
                <pre className="p-4 rounded-lg bg-slate-950 text-slate-100 text-xs font-mono overflow-x-auto max-h-80 leading-relaxed">
                  {winResult.files_preview?.[selectedWinFile] || ''}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {builderTab === 'code' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-4 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">SK-CODE Multi-Language Generator</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Target Language (17 Supported)</label>
              <select
                value={codeLang}
                onChange={(e) => setCodeLang(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              >
                {LANGUAGES.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Specification</label>
              <textarea
                rows={3}
                value={codePrompt}
                onChange={(e) => setCodePrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <button
              onClick={generateCode}
              disabled={loading}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
            >
              {loading ? 'Synthesizing Code...' : 'Generate & Inspect Code'}
            </button>
          </div>

          <div className={`lg:col-span-8 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Synthesized Source &amp; AST Analysis</h3>
            {!codeResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Select a language and click &ldquo;Generate &amp; Inspect Code&rdquo;.
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Language: {codeResult.language}</span>
                  <span>·</span>
                  <span>Syntax Valid: {String(codeResult.syntax_valid)}</span>
                  <span>·</span>
                  <span>{codeResult.analysis?.summary}</span>
                </div>
                <pre className="p-4 rounded-lg bg-slate-950 text-slate-100 text-xs font-mono overflow-x-auto leading-relaxed">
                  {codeResult.code}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
