"""
SKStemProcessor: Exports individual stem tracks (melody, harmony, bass, percussion) as WAV files.
"""

import os
import wave
import struct
from typing import Dict, Any, List


class SKStemProcessor:
    @staticmethod
    def export_stems(
        stems_buffers: Dict[str, List[float]],
        output_dir: str = "models/weights/stems",
        sample_rate: int = 16000,
    ) -> Dict[str, str]:
        os.makedirs(output_dir, exist_ok=True)
        paths: Dict[str, str] = {}
        for name, buf in stems_buffers.items():
            stem_path = os.path.join(output_dir, f"{name}_stem.wav")
            pcm = bytearray()
            for val in buf:
                s = max(-32767, min(32767, int(val * 22000)))
                pcm.extend(struct.pack("<h", s))
            with wave.open(stem_path, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sample_rate)
                wf.writeframes(bytes(pcm))
            paths[name] = stem_path
        return paths
