"""
Unified Hardware Detector for CPU, RAM, GPU/VRAM, and Disk Storage.
"""

import os
import platform
import shutil
from typing import Dict, Any
from .memory import MemoryInspector
from .gpu import GPUDetector


class HardwareDetector:
    @staticmethod
    def get_cpu_info() -> Dict[str, Any]:
        model_name = platform.processor() or platform.machine() or "Generic CPU"
        if os.path.exists("/proc/cpuinfo"):
            try:
                with open("/proc/cpuinfo", "r", encoding="utf-8") as f:
                    for line in f:
                        if "model name" in line:
                            model_name = line.split(":", 1)[1].strip()
                            break
            except Exception:
                pass
        return {
            "model_name": model_name,
            "architecture": platform.machine(),
            "logical_cores": os.cpu_count() or 1,
            "os": f"{platform.system()} {platform.release()}",
        }

    @staticmethod
    def get_storage_info(path: str = ".") -> Dict[str, Any]:
        usage = shutil.disk_usage(os.path.abspath(path))
        return {
            "path": os.path.abspath(path),
            "total_bytes": usage.total,
            "used_bytes": usage.used,
            "free_bytes": usage.free,
            "total_gb": round(usage.total / (1024**3), 2),
            "used_gb": round(usage.used / (1024**3), 2),
            "free_gb": round(usage.free / (1024**3), 2),
            "supports_1tb_library_now": usage.free >= (1024**4),
        }

    @classmethod
    def detect_all(cls, workspace_path: str = ".") -> Dict[str, Any]:
        cpu = cls.get_cpu_info()
        ram = MemoryInspector.get_system_memory()
        gpu = GPUDetector.detect_gpus()
        storage = cls.get_storage_info(workspace_path)
        return {
            "cpu": cpu,
            "memory": ram,
            "gpu": gpu,
            "storage": storage,
        }
