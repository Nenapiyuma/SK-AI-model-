"""
SK AI Command-Line Interface (`skai/cli.py`).
Supports:
- skai chat
- skai generate
- skai code
- skai image
- skai music
- skai video
- skai audio
- skai speech
- skai vision
- skai android
- skai windows
- skai models [list|info|install|remove]
- skai hardware
- skai benchmark
"""

import sys
import json
import argparse
from core.skai import SKAI
from evaluation.suite import SKEvaluationSuite


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="skai", description="SK AI Local-First Multimodal AI CLI")
    sub = parser.add_subparsers(dest="command")

    for cmd in [
        "chat", "generate", "code", "image", "music", "video",
        "audio", "speech", "vision", "android", "windows",
        "models", "hardware", "benchmark"
    ]:
        p = sub.add_parser(cmd)
        p.add_argument("args", nargs="*", help=f"Arguments for {cmd}")

    parsed = parser.parse_args(argv)
    if not parsed.command:
        parser.print_help()
        return 0

    ai = SKAI()
    cmd = parsed.command
    rest = " ".join(parsed.args).strip()

    if cmd in ("chat", "generate"):
        res = ai.chat(rest or "Explain quantum computing in Sinhala.")
        print(res["answer"])
    elif cmd == "code":
        res = ai.generate_code(rest or "Write a Python task processor")
        print(res["code"])
    elif cmd == "image":
        res = ai.generate_image(rest or "Calm ocean horizon in Sri Lanka")
        print(json.dumps({k: v for k, v in res.items() if k != "data_url"}, indent=2))
    elif cmd == "music":
        res = ai.generate_music(rest or "Create a happy Sinhala pop song")
        print(json.dumps({k: v for k, v in res.items() if k != "audio_data_url"}, indent=2))
    elif cmd == "video":
        res = ai.generate_video(rest or "Sunrise over mountains")
        print(json.dumps({k: v for k, v in res.items() if k != "frame_data_urls"}, indent=2))
    elif cmd == "speech":
        res = ai.synthesize_speech(rest or "Ayubowan SK AI")
        print(json.dumps({k: v for k, v in res.items() if k != "data_url"}, indent=2))
    elif cmd == "audio":
        res = ai.synthesize_speech("SK AI Audio Test")
        analysis = ai.orchestrator.audio_model.analyze_wav(res["output_path"])
        print(json.dumps(analysis, indent=2))
    elif cmd == "vision":
        img = ai.generate_image("Sample test pattern")
        vis = ai.analyze_image(img["output_path"], question=rest or "Inspect image")
        print(json.dumps(vis, indent=2))
    elif cmd == "android":
        res = ai.create_android_project(prompt=rest or "Create a Sinhala AI chat app.")
        print(json.dumps({k: v for k, v in res.items() if k != "files_preview"}, indent=2))
    elif cmd == "windows":
        res = ai.create_windows_project(prompt=rest or "Make this HTML app into a Windows EXE.")
        print(json.dumps({k: v for k, v in res.items() if k != "files_preview"}, indent=2))
    elif cmd == "models":
        action = parsed.args[0] if parsed.args else "list"
        target = parsed.args[1] if len(parsed.args) > 1 else "sk-llm-mini"
        if action == "info":
            print(json.dumps(ai.model_manager.get_model_info(target), indent=2))
        else:
            for m in ai.model_manager.list_models():
                print(f"{m['id']:30s} | {m['status']:14s} | {m['origin']:18s} | {m['parameter_count']:,} params")
    elif cmd == "hardware":
        print(json.dumps(ai.get_hardware_status(), indent=2))
    elif cmd == "benchmark":
        suite = SKEvaluationSuite()
        print(json.dumps(suite.run_all_evaluations(), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
