"""
SKMusicAudioGenerator: Polyphonic Multi-Track WAV Synthesizer for SK-MUSIC.
Synthesizes lead melody, triad chord harmony, bassline, and rhythmic percussion into 16-bit PCM WAV.
"""

import os
import wave
import math
import struct
import base64
from typing import Dict, Any, List


def midi_to_hz(midi_note: int) -> float:
    return 440.0 * (2.0 ** ((midi_note - 69.0) / 12.0))


class SKMusicAudioGenerator:
    def render_wav(
        self,
        composition: Dict[str, Any],
        output_path: str = "models/weights/generated_music.wav",
        sample_rate: int = 16000,
    ) -> Dict[str, Any]:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        duration_sec = float(composition.get("duration_sec", 4.0))
        total_samples = max(int(sample_rate * 1.0), int(duration_sec * sample_rate))
        melody_notes = composition.get("melody_notes", [])
        chords = composition.get("chord_progression", [{"notes": [48, 52, 55]}])
        backing_only = bool(composition.get("backing_track_mode", False))

        melody_buf = [0.0] * total_samples
        harmony_buf = [0.0] * total_samples
        bass_buf = [0.0] * total_samples
        perc_buf = [0.0] * total_samples

        # 1. Lead Melody Stem
        if not backing_only:
            for note in melody_notes:
                freq = midi_to_hz(note["midi_note"])
                s_idx = int(note["start_sec"] * sample_rate)
                e_idx = min(total_samples, s_idx + int(note["duration_sec"] * sample_rate))
                length = max(1, e_idx - s_idx)
                for i in range(s_idx, e_idx):
                    rel = (i - s_idx) / length
                    env = math.sin(math.pi * rel) ** 0.6
                    t = i / sample_rate
                    # Rich harmonic lead (fundamental + 2nd & 3rd overtones)
                    melody_buf[i] += env * (
                        0.65 * math.sin(2.0 * math.pi * freq * t)
                        + 0.22 * math.sin(4.0 * math.pi * freq * t)
                        + 0.10 * math.sin(6.0 * math.pi * freq * t)
                    )

        # 2. Chord Harmony & Bass Stems
        chord_dur_samples = max(1, total_samples // max(1, len(chords)))
        for c_idx, chord in enumerate(chords):
            c_start = c_idx * chord_dur_samples
            c_end = min(total_samples, (c_idx + 1) * chord_dur_samples)
            c_freqs = [midi_to_hz(n) for n in chord["notes"]]
            bass_freq = midi_to_hz(chord["notes"][0] - 12)
            for i in range(c_start, c_end):
                t = i / sample_rate
                harmony_buf[i] = sum(math.sin(2.0 * math.pi * f * t) for f in c_freqs) / len(c_freqs)
                bass_buf[i] = math.sin(2.0 * math.pi * bass_freq * t)

        # 3. Percussion Stem (Kick/Hi-hat pulse on beat)
        bpm = composition.get("tempo_bpm", 120)
        beat_samples = max(1, int((60.0 / bpm) * sample_rate))
        for i in range(total_samples):
            pos_in_beat = i % beat_samples
            if pos_in_beat < int(0.06 * sample_rate):
                decay = 1.0 - (pos_in_beat / (0.06 * sample_rate))
                perc_buf[i] = decay * math.sin(2.0 * math.pi * 65.0 * (pos_in_beat / sample_rate))

        # Mixdown
        pcm = bytearray()
        for i in range(total_samples):
            mix = 0.42 * melody_buf[i] + 0.26 * harmony_buf[i] + 0.20 * bass_buf[i] + 0.12 * perc_buf[i]
            sample_int = max(-32767, min(32767, int(mix * 26000)))
            pcm.extend(struct.pack("<h", sample_int))

        with wave.open(output_path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(bytes(pcm))

        with open(output_path, "rb") as f:
            wav_bytes = f.read()

        return {
            "wav_path": output_path,
            "file_size_bytes": len(wav_bytes),
            "duration_sec": duration_sec,
            "sample_rate": sample_rate,
            "data_url": "data:audio/wav;base64," + base64.b64encode(wav_bytes).decode("ascii"),
            "_stems_buffers": {
                "melody": melody_buf,
                "harmony": harmony_buf,
                "bass": bass_buf,
                "percussion": perc_buf,
            },
        }
