"""
ImageToImageGenerator: Conditioning an existing image buffer with a text prompt and strength factor.
"""

import os
import base64
from typing import Dict, Any
from .conditioning import PromptConditioner
from .sampler import IterativeDiffusionSampler


class ImageToImageGenerator:
    def __init__(self):
        self.conditioner = PromptConditioner()
        self.sampler = IterativeDiffusionSampler()

    def generate(
        self,
        prompt: str,
        strength: float = 0.65,
        width: int = 160,
        height: int = 160,
        seed: int = 42,
        output_path: str = "models/weights/generated_img2img.png",
    ) -> Dict[str, Any]:
        cond = self.conditioner.encode_prompt(prompt)
        init_rgb = bytes([120, 130, 150] * (width * height))
        png_bytes, meta = self.sampler.sample_rgb_grid(
            conditioning=cond,
            width=width,
            height=height,
            steps=10,
            seed=seed,
            init_rgb=init_rgb,
            strength=strength,
        )
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "wb") as f:
            f.write(png_bytes)
        return {
            "subsystem": "SK-IMAGE",
            "mode": "image_to_image",
            "prompt": prompt,
            "strength": strength,
            "output_path": output_path,
            "file_size_bytes": len(png_bytes),
            "data_url": "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii"),
            **meta,
        }
