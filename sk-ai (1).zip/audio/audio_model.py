"""
SKAudioModel: Local WAV Signal Analyzer, Voice Activity Detector (VAD) & Audio Generator.
"""

import os
import wave
import math
import struct
from typing import Dict, Any, List


class SKAudioModel:
    def __init__(self, weights_dir: str = "models/weights"):
        self.weights_dir = weights_dir
        self.whisper_path = os.path.join(weights_dir, "whisper_large_v3_fp16.safetensors")

    def analyze_wav(self, filepath: str) -> Dict[str, Any]:
        if not os.path.exists(filepath):
            return {"exists": False, "error": f"Audio file not found: {filepath}"}

        with wave.open(filepath, "rb") as wf:
            channels = wf.getnchannels()
            sample_width = wf.getsampwidth()
            sample_rate = wf.getframerate()
            num_frames = wf.getnframes()
            raw = wf.readframes(num_frames)

        duration_sec = num_frames / max(1, sample_rate)
        samples: List[float] = []
        if sample_width == 2:
            count = len(raw) // 2
            ints = struct.unpack(f"<{count}h", raw[: count * 2])
            samples = [v / 32768.0 for v in ints[:: max(1, channels)]]

        if not samples:
            return {"exists": True, "duration_sec": 0.0, "rms_energy": 0.0, "vad_active": False}

        rms = math.sqrt(sum(s * s for s in samples) / len(samples))
        zcr = sum(1 for i in range(1, len(samples)) if (samples[i] >= 0) != (samples[i - 1] >= 0)) / max(
            1, len(samples)
        )

        # Frame-level Voice Activity Detection (VAD)
        frame_size = max(1, int(sample_rate * 0.05))
        active_frames = 0
        total_frames = 0
        for start in range(0, len(samples), frame_size):
            chunk = samples[start : start + frame_size]
            if chunk:
                total_frames += 1
                f_rms = math.sqrt(sum(c * c for c in chunk) / len(chunk))
                if f_rms > 0.02:
                    active_frames += 1

        return {
            "exists": True,
            "filepath": filepath,
            "channels": channels,
            "sample_rate": sample_rate,
            "duration_sec": round(duration_sec, 3),
            "rms_energy": round(rms, 4),
            "zero_crossing_rate": round(zcr, 4),
            "vad_active_ratio": round(active_frames / max(1, total_frames), 3),
            "vad_speech_detected": active_frames > 0,
        }
