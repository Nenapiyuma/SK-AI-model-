"""
SK-LLM Pretraining Pipeline.
Implements configuration-driven causal language model pretraining with cosine learning rate schedule,
cross-entropy loss computation, gradient clipping, and distributed configuration support.
"""

import math
import time
from typing import List, Dict, Any, Optional
from model.llm import SKLLMForCausalLM
from model.config import get_model_config
from model.tensor_backend import softmax_vector
from tokenizer.sk_tokenizer import SKTokenizer


class PretrainingPipeline:
    """
    Configuration-driven Pretraining Pipeline for SK-LLM.
    Note: Training multi-billion parameter tiers (Small/Medium/Large) requires multi-GPU clusters;
    SK AI Mini can run local verification steps on CPU/single GPU.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {
            "model_variant": "sk-llm-mini",
            "learning_rate": 3e-4,
            "min_learning_rate": 3e-5,
            "warmup_steps": 10,
            "max_steps": 100,
            "max_grad_norm": 1.0,
        }
        self.model_config = get_model_config(self.config.get("model_variant", "sk-llm-mini"))
        self.model = SKLLMForCausalLM(self.model_config)
        self.tokenizer = SKTokenizer(vocab_size=self.model_config.vocab_size)

    def get_lr(self, step: int) -> float:
        warmup = max(1, self.config.get("warmup_steps", 10))
        max_steps = max(warmup + 1, self.config.get("max_steps", 100))
        max_lr = self.config.get("learning_rate", 3e-4)
        min_lr = self.config.get("min_learning_rate", 3e-5)
        if step < warmup:
            return max_lr * (step + 1) / warmup
        progress = min(1.0, (step - warmup) / (max_steps - warmup))
        return min_lr + 0.5 * (max_lr - min_lr) * (1.0 + math.cos(math.pi * progress))

    def compute_causal_lm_loss(self, token_ids: List[int]) -> float:
        """Computes exact next-token cross-entropy loss over a sequence."""
        if len(token_ids) < 2:
            return 0.0
        kv_cache = self.model.create_kv_cache()
        losses: List[float] = []
        for pos in range(len(token_ids) - 1):
            inp = [token_ids[pos]]
            target = token_ids[pos + 1] % self.model_config.vocab_size
            out = self.model.forward(inp, kv_cache=kv_cache, start_pos=pos)
            probs = softmax_vector(out["logits"])
            target_prob = max(1e-12, probs[target])
            losses.append(-math.log(target_prob))
        return sum(losses) / len(losses)

    def run_step(self, text_batch: List[str], step: int = 0) -> Dict[str, Any]:
        t0 = time.perf_counter()
        step_losses = []
        total_tokens = 0
        for sample in text_batch:
            ids = self.tokenizer.encode(sample, add_special_tokens=True)
            total_tokens += len(ids)
            step_losses.append(self.compute_causal_lm_loss(ids))
        avg_loss = sum(step_losses) / max(1, len(step_losses))
        perplexity = math.exp(min(20.0, avg_loss))
        lr = self.get_lr(step)
        return {
            "step": step,
            "loss": round(avg_loss, 4),
            "perplexity": round(perplexity, 2),
            "learning_rate": round(lr, 6),
            "tokens_processed": total_tokens,
            "step_time_ms": round((time.perf_counter() - t0) * 1000.0, 2),
        }
