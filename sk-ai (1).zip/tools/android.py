"""
AndroidTool: Inspects Android Studio projects and delegates full Kotlin/Compose generation
to `android.generator.SKAndroidGenerator`.
"""

import os
from typing import Dict, Any


class AndroidTool:
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = workspace_root

    def inspect_android_project(self, project_dir: str) -> Dict[str, Any]:
        manifest = os.path.join(project_dir, "app", "src", "main", "AndroidManifest.xml")
        gradle = os.path.join(project_dir, "app", "build.gradle.kts")
        return {
            "project_dir": project_dir,
            "has_manifest": os.path.exists(manifest),
            "has_gradle_kts": os.path.exists(gradle),
            "valid_android_structure": os.path.exists(manifest) and os.path.exists(gradle),
        }
