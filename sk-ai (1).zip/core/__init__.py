"""
SK AI Core Package (`core/`).
Contains:
- `config.py` (System & Privacy Configuration)
- `session.py` (Conversation & Workspace Session Manager)
- `router.py` (Core Router Bridge)
- `orchestrator.py` (USER -> INTENT -> MODEL ROUTING -> TOOLS -> MODEL EXECUTION -> VALIDATION -> FINAL RESPONSE)
- `skai.py` (Unified SKAI Python API)
"""

from .config import SKAIConfig
from .session import SKAISession
from .router import CoreRouter
from .orchestrator import SKAIOrchestrator
from .skai import SKAI

__all__ = [
    "SKAIConfig",
    "SKAISession",
    "CoreRouter",
    "SKAIOrchestrator",
    "SKAI",
]
