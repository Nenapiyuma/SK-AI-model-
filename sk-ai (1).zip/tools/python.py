"""
PythonTool: Restricted safe Python expression & snippet evaluator.
Blocks dangerous system imports (`os.system`, `subprocess`, `shutil.rmtree`) unless confirmed.
"""

import ast
from typing import Dict, Any


BANNED_CALLS = {"system", "popen", "rmtree", "remove", "unlink", "eval", "exec"}


class PythonTool:
    def evaluate_safe(self, code: str) -> Dict[str, Any]:
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    if node.func.attr in BANNED_CALLS:
                        return {
                            "executed": False,
                            "blocked": True,
                            "error": f"Security sandbox blocked potentially destructive call: {node.func.attr}",
                        }
            local_ns: Dict[str, Any] = {}
            safe_builtins = {
                "abs": abs, "all": all, "any": any, "dict": dict, "enumerate": enumerate,
                "float": float, "int": int, "len": len, "list": list, "max": max, "min": min,
                "pow": pow, "range": range, "round": round, "set": set, "sorted": sorted,
                "str": str, "sum": sum, "tuple": tuple, "zip": zip,
            }
            exec(compile(tree, "<skai_sandbox>", "exec"), {"__builtins__": safe_builtins}, local_ns)
            return {"executed": True, "variables": {k: repr(v) for k, v in local_ns.items()}}
        except Exception as e:
            return {"executed": False, "error": str(e)}
