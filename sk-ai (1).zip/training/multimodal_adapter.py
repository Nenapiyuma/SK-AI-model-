"""
Vision-Language Multimodal Adapter Training Pipeline.
Projects vision encoder patch embeddings into SK-LLM hidden dimension space using a 2-layer MLP projector.
"""

from typing import List, Dict, Any
from model.tensor_backend import SKMatrix, silu_vector


class MultimodalAdapterTrainer:
    """
    2-Layer MLP Vision-Language Connector (vision_dim -> hidden_size -> hidden_size).
    """

    def __init__(self, vision_dim: int = 64, llm_hidden_size: int = 128):
        self.vision_dim = vision_dim
        self.llm_hidden_size = llm_hidden_size
        self.proj_1 = SKMatrix(vision_dim, llm_hidden_size, seed=301)
        self.proj_2 = SKMatrix(llm_hidden_size, llm_hidden_size, seed=302)

    def project_visual_features(self, patch_features: List[List[float]]) -> List[List[float]]:
        projected: List[List[float]] = []
        for feat in patch_features:
            padded = (feat + [0.0] * self.vision_dim)[: self.vision_dim]
            h = silu_vector(self.proj_1.vecmat(padded))
            out = self.proj_2.vecmat(h)
            projected.append(out)
        return projected

    def num_parameters(self) -> int:
        return self.proj_1.numel + self.proj_2.numel
