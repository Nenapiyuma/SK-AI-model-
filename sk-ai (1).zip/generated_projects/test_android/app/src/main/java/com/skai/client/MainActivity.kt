package com.skai.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class ExecutionMode {
    LOCAL_ON_DEVICE,
    WINDOWS_PC_LAN
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SKAIChatScreen()
            }
        }
    }
}

@Composable
fun SKAIChatScreen() {
    var mode by remember { mutableStateOf(ExecutionMode.LOCAL_ON_DEVICE) }
    var lanHost by remember { mutableStateOf("http://192.168.1.100:3000") }
    var inputPrompt by remember { mutableStateOf("ක්වොන්ටම් පරිගණනය පැහැදිලි කරන්න") }
    var reply by remember { mutableStateOf("ආයුබෝවන්! SK AI Local Engine සූදානම්.") }

    Scaffold {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(it)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = "SKAISinhalaChat", style = MaterialTheme.typography.headlineSmall)
            Text(
                text = if (mode == ExecutionMode.LOCAL_ON_DEVICE)
                    "ACTIVE MODE: A — Local On-Device SK AI Mini (Offline)"
                else
                    "ACTIVE MODE: B — Connected to Windows PC over LAN ($lanHost)",
                style = MaterialTheme.typography.labelLarge
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { mode = ExecutionMode.LOCAL_ON_DEVICE }) {
                    Text("Mode A: Local Phone")
                }
                Button(onClick = { mode = ExecutionMode.WINDOWS_PC_LAN }) {
                    Text("Mode B: Windows PC LAN")
                }
            }
            OutlinedTextField(
                value = inputPrompt,
                onValueChange = { inputPrompt = it },
                label = { Text("ප්‍රශ්නය ඇතුළත් කරන්න / Enter Prompt") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                reply = "[${mode.name}] සැකසූ පිළිතුර: $inputPrompt"
            }) {
                Text("Send / යවන්න")
            }
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Text(text = reply, modifier = Modifier.padding(16.dp))
            }
        }
    }
}
