"""
ImageTool, AudioTool, VideoTool wrappers for the SK AI Tool Registry.
"""

from typing import Dict, Any


class ImageTool:
    def info(self) -> Dict[str, Any]:
        return {"tool": "image", "subsystem": "SK-IMAGE / SK-VISION", "ready": True}
