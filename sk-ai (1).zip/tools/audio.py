from typing import Dict, Any


class AudioTool:
    def info(self) -> Dict[str, Any]:
        return {"tool": "audio", "subsystem": "SK-AUDIO / SK-MUSIC / SK-SPEECH", "ready": True}
