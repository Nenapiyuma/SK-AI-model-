"""
TextToVideoPipeline, ImageToVideoPipeline, and VideoToVideoPipeline for SK-VIDEO.
"""

from typing import Dict, Any
from .frame_processor import VideoFrameProcessor


class TextToVideoPipeline:
    def __init__(self):
        self.processor = VideoFrameProcessor()

    def generate(
        self,
        prompt: str,
        duration_sec: float = 1.5,
        fps: int = 4,
        width: int = 128,
        height: int = 96,
        seed: int = 42,
    ) -> Dict[str, Any]:
        num_frames = max(2, min(12, int(round(duration_sec * fps))))
        frames = self.processor.render_frames(prompt, num_frames=num_frames, width=width, height=height, seed=seed)
        return {"mode": "text_to_video", "frames": frames, "fps": fps, "duration_sec": duration_sec}
