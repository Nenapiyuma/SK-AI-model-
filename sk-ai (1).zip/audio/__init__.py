"""
SK-AUDIO Subsystem (`audio/`).
Provides WAV audio analysis, RMS energy, Zero-Crossing Rate (ZCR), Voice Activity Detection (VAD),
and local waveform synthesis.
"""

from .audio_model import SKAudioModel

__all__ = ["SKAudioModel"]
