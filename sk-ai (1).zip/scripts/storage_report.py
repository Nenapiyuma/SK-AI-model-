#!/usr/bin/env python3
"""
SK AI Model Size / Storage Report (`scripts/storage_report.py`).
Outputs:
    SK AI Storage Report
    Component | Size | Parameters | Quantization | Status | License
    TOTAL INSTALLED SIZE
    TOTAL AVAILABLE MODEL LIBRARY SIZE
Never artificially inflates files to reach 1 TB.
"""

import os
import sys
import json

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from model_manager.manager import SKModelManager


def format_bytes(num_bytes: int) -> str:
    if num_bytes == 0:
        return "0 B (0 MB)"
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1024**2:
        return f"{num_bytes / 1024:.2f} KB"
    if num_bytes < 1024**3:
        return f"{num_bytes / (1024**2):.2f} MB"
    return f"{num_bytes / (1024**3):.2f} GB"


def generate_storage_report() -> dict:
    mm = SKModelManager(workspace_root=ROOT_DIR)
    summary = mm.get_storage_summary()
    rows = []
    for m in summary["models"]:
        actual_or_target = m["file_size"] if m["status"] == "INSTALLED" else m.get("target_library_size_bytes", 0)
        rows.append(
            {
                "component": m["name"],
                "subsystem": m["subsystem"],
                "origin": m["origin"],
                "size_bytes": m["file_size"],
                "size_formatted": format_bytes(m["file_size"])
                if m["status"] == "INSTALLED"
                else f"0 B installed (Library Est: {format_bytes(actual_or_target)})",
                "parameters": m["parameter_count"],
                "quantization": m["quantization"],
                "status": m["status"],
                "license": m["license"],
                "sha256": m["sha256"],
            }
        )
    return {
        "rows": rows,
        "total_installed_bytes": summary["total_installed_bytes"],
        "total_installed_formatted": format_bytes(summary["total_installed_bytes"]),
        "total_available_library_bytes": summary["total_available_library_bytes"],
        "total_available_library_formatted": format_bytes(summary["total_available_library_bytes"]),
        "architecture_max_budget": "1.00 TB (1,099,511,627,776 B Modular Target Budget)",
    }


if __name__ == "__main__":
    rep = generate_storage_report()
    print("SK AI Storage Report")
    print("=" * 118)
    header = f"{'Component':42s} | {'Size':32s} | {'Parameters':14s} | {'Quant':6s} | {'Status':13s} | {'License':10s}"
    print(header)
    print("-" * 118)
    for r in rep["rows"]:
        p_str = f"{r['parameters']:,}"
        print(
            f"{r['component'][:42]:42s} | {r['size_formatted'][:32]:32s} | {p_str:14s} | "
            f"{r['quantization']:6s} | {r['status']:13s} | {r['license'][:10]:10s}"
        )
    print("=" * 118)
    print(f"TOTAL INSTALLED SIZE               : {rep['total_installed_formatted']} ({rep['total_installed_bytes']:,} bytes)")
    print(f"TOTAL AVAILABLE MODEL LIBRARY SIZE : {rep['total_available_library_formatted']} ({rep['total_available_library_bytes']:,} bytes)")
    print(f"ARCHITECTURE SCALING BUDGET        : {rep['architecture_max_budget']}")
