"""
SK-LLM Transformer Architectural Layers:
- RMSNorm (Root Mean Square Layer Normalization)
- RotaryEmbedding (RoPE)
- SwiGLUMLP (Swish-Gated Linear Unit Feed-Forward Network)
- KVCache (Key-Value Attention Cache for fast autoregressive decoding)
- GroupedQueryAttention (Causal GQA with RoPE and KV Cache)
- SKDecoderLayer (Pre-norm Transformer Decoder Block)
"""

import math
from typing import List, Tuple, Optional, Dict, Any
from .config import SKLLMConfig
from .tensor_backend import SKMatrix, rms_norm_vector, silu_vector, softmax_vector


class RMSNorm:
    """Root Mean Square Layer Normalization."""

    def __init__(self, hidden_size: int, eps: float = 1e-6):
        self.hidden_size = hidden_size
        self.eps = eps
        self.weight: List[float] = [1.0] * hidden_size

    def forward(self, hidden_states: List[List[float]]) -> List[List[float]]:
        return [rms_norm_vector(vec, self.weight, self.eps) for vec in hidden_states]

    def num_parameters(self) -> int:
        return self.hidden_size


class RotaryEmbedding:
    """Rotary Positional Embeddings (RoPE) for Query and Key vectors."""

    def __init__(self, dim: int, max_position_embeddings: int = 4096, base: float = 10000.0):
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.inv_freq = [
            1.0 / (self.base ** (float(i) / self.dim)) for i in range(0, self.dim, 2)
        ]

    def apply_rotary_emb(self, vec: List[float], position: int) -> List[float]:
        """Rotate a single head vector of length `self.dim` at token index `position`."""
        out = [0.0] * self.dim
        half = self.dim // 2
        for i in range(half):
            angle = position * self.inv_freq[i]
            cos_a = math.cos(angle)
            sin_a = math.sin(angle)
            x1 = vec[i]
            x2 = vec[i + half]
            out[i] = x1 * cos_a - x2 * sin_a
            out[i + half] = x2 * cos_a + x1 * sin_a
        return out


class KVCache:
    """Stores past Key and Value states per layer for fast O(T) autoregressive generation."""

    def __init__(self, num_layers: int):
        self.num_layers = num_layers
        # layer_idx -> list of token steps -> list of kv_heads -> head_dim vector
        self.k_cache: List[List[List[List[float]]]] = [[] for _ in range(num_layers)]
        self.v_cache: List[List[List[List[float]]]] = [[] for _ in range(num_layers)]

    def update(
        self,
        layer_idx: int,
        k_step: List[List[List[float]]],
        v_step: List[List[List[float]]],
    ) -> Tuple[List[List[List[float]]], List[List[List[float]]]]:
        self.k_cache[layer_idx].extend(k_step)
        self.v_cache[layer_idx].extend(v_step)
        return self.k_cache[layer_idx], self.v_cache[layer_idx]

    def seq_len(self, layer_idx: int = 0) -> int:
        return len(self.k_cache[layer_idx])

    def clear(self) -> None:
        for i in range(self.num_layers):
            self.k_cache[i].clear()
            self.v_cache[i].clear()


class GroupedQueryAttention:
    """
    Causal Grouped-Query Attention (GQA) with Rotary Position Embeddings and KV Caching.
    """

    def __init__(self, config: SKLLMConfig, layer_idx: int = 0):
        self.config = config
        self.layer_idx = layer_idx
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.num_kv_heads = config.num_key_value_heads
        self.head_dim = config.head_dim
        self.num_kv_groups = config.num_key_value_groups

        seed_base = 1000 + layer_idx * 37
        self.q_proj = SKMatrix(self.hidden_size, self.num_heads * self.head_dim, seed=seed_base + 1)
        self.k_proj = SKMatrix(self.hidden_size, self.num_kv_heads * self.head_dim, seed=seed_base + 2)
        self.v_proj = SKMatrix(self.hidden_size, self.num_kv_heads * self.head_dim, seed=seed_base + 3)
        self.o_proj = SKMatrix(self.num_heads * self.head_dim, self.hidden_size, seed=seed_base + 4)
        self.rotary_emb = RotaryEmbedding(
            dim=self.head_dim,
            max_position_embeddings=config.max_position_embeddings,
            base=config.rope_theta,
        )

    def num_parameters(self) -> int:
        return (
            self.q_proj.numel
            + self.k_proj.numel
            + self.v_proj.numel
            + self.o_proj.numel
        )

    def forward(
        self,
        hidden_states: List[List[float]],
        kv_cache: Optional[KVCache] = None,
        start_pos: int = 0,
    ) -> List[List[float]]:
        seq_len = len(hidden_states)
        q_seq: List[List[List[float]]] = []
        k_seq: List[List[List[float]]] = []
        v_seq: List[List[List[float]]] = []

        for t in range(seq_len):
            pos = start_pos + t
            x = hidden_states[t]
            q_flat = self.q_proj.vecmat(x)
            k_flat = self.k_proj.vecmat(x)
            v_flat = self.v_proj.vecmat(x)

            q_heads = []
            for h in range(self.num_heads):
                vec = q_flat[h * self.head_dim : (h + 1) * self.head_dim]
                q_heads.append(self.rotary_emb.apply_rotary_emb(vec, pos))

            k_heads = []
            v_heads = []
            for kh in range(self.num_kv_heads):
                k_vec = k_flat[kh * self.head_dim : (kh + 1) * self.head_dim]
                v_vec = v_flat[kh * self.head_dim : (kh + 1) * self.head_dim]
                k_heads.append(self.rotary_emb.apply_rotary_emb(k_vec, pos))
                v_heads.append(v_vec)

            q_seq.append(q_heads)
            k_seq.append(k_heads)
            v_seq.append(v_heads)

        if kv_cache is not None and self.config.use_cache:
            k_all, v_all = kv_cache.update(self.layer_idx, k_seq, v_seq)
        else:
            k_all, v_all = k_seq, v_seq

        total_k_len = len(k_all)
        scale = 1.0 / math.sqrt(max(1, self.head_dim))
        outputs: List[List[float]] = []

        for t in range(seq_len):
            query_abs_pos = start_pos + t
            concat_heads: List[float] = []
            for h in range(self.num_heads):
                kv_h = h // self.num_kv_groups
                q_vec = q_seq[t][h]
                # Causal mask: only attend up to query_abs_pos
                valid_len = min(total_k_len, query_abs_pos + 1)
                scores = [0.0] * valid_len
                for j in range(valid_len):
                    k_vec = k_all[j][kv_h]
                    dot = sum(q_vec[d] * k_vec[d] for d in range(self.head_dim))
                    scores[j] = dot * scale
                probs = softmax_vector(scores)
                head_out = [0.0] * self.head_dim
                for j in range(valid_len):
                    p = probs[j]
                    v_vec = v_all[j][kv_h]
                    for d in range(self.head_dim):
                        head_out[d] += p * v_vec[d]
                concat_heads.extend(head_out)
            outputs.append(self.o_proj.vecmat(concat_heads))

        return outputs


class SwiGLUMLP:
    """
    SwiGLU Feed-Forward Network: down_proj(SiLU(gate_proj(x)) * up_proj(x)).
    """

    def __init__(self, config: SKLLMConfig, layer_idx: int = 0):
        self.hidden_size = config.hidden_size
        self.intermediate_size = config.intermediate_size
        seed_base = 5000 + layer_idx * 41
        self.gate_proj = SKMatrix(self.hidden_size, self.intermediate_size, seed=seed_base + 1)
        self.up_proj = SKMatrix(self.hidden_size, self.intermediate_size, seed=seed_base + 2)
        self.down_proj = SKMatrix(self.intermediate_size, self.hidden_size, seed=seed_base + 3)

    def num_parameters(self) -> int:
        return self.gate_proj.numel + self.up_proj.numel + self.down_proj.numel

    def forward(self, hidden_states: List[List[float]]) -> List[List[float]]:
        outputs: List[List[float]] = []
        for x in hidden_states:
            gate = silu_vector(self.gate_proj.vecmat(x))
            up = self.up_proj.vecmat(x)
            fused = [gate[i] * up[i] for i in range(self.intermediate_size)]
            outputs.append(self.down_proj.vecmat(fused))
        return outputs


class SKDecoderLayer:
    """Single Transformer Decoder Block with Pre-RMSNorm, Causal GQA, and SwiGLU MLP."""

    def __init__(self, config: SKLLMConfig, layer_idx: int):
        self.layer_idx = layer_idx
        self.input_layernorm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.self_attn = GroupedQueryAttention(config, layer_idx=layer_idx)
        self.post_attention_layernorm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.mlp = SwiGLUMLP(config, layer_idx=layer_idx)

    def num_parameters(self) -> int:
        return (
            self.input_layernorm.num_parameters()
            + self.self_attn.num_parameters()
            + self.post_attention_layernorm.num_parameters()
            + self.mlp.num_parameters()
        )

    def forward(
        self,
        hidden_states: List[List[float]],
        kv_cache: Optional[KVCache] = None,
        start_pos: int = 0,
    ) -> List[List[float]]:
        normed = self.input_layernorm.forward(hidden_states)
        attn_out = self.self_attn.forward(normed, kv_cache=kv_cache, start_pos=start_pos)
        h1 = [
            [hidden_states[t][d] + attn_out[t][d] for d in range(len(hidden_states[t]))]
            for t in range(len(hidden_states))
        ]
        normed2 = self.post_attention_layernorm.forward(h1)
        mlp_out = self.mlp.forward(normed2)
        h2 = [
            [h1[t][d] + mlp_out[t][d] for d in range(len(h1[t]))]
            for t in range(len(h1))
        ]
        return h2
