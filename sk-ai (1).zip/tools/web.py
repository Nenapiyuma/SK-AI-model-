"""
WebTool: Network & Web Fetch Tool with strict `offline_mode=True` enforcement.
When `offline_mode=True`, all external network requests are blocked to guarantee local privacy.
"""

from typing import Dict, Any


class WebTool:
    def __init__(self, offline_mode: bool = True):
        self.offline_mode = offline_mode

    def fetch(self, url: str) -> Dict[str, Any]:
        if self.offline_mode:
            return {
                "ok": False,
                "blocked_by_offline_mode": True,
                "message": "External network access is disabled because `offline_mode=true` is active.",
            }
        return {"ok": True, "url": url, "message": "External network permitted."}
