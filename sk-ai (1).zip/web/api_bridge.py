#!/usr/bin/env python3
"""
JSON CLI Bridge (`web/api_bridge.py`) invoked by `server.ts` so the Web UI interacts
with the genuine Python SK AI ecosystem in real time.
"""

import os
import sys
import json

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from core.skai import SKAI
from scripts.smoke_test import run_smoke_test
from scripts.storage_report import generate_storage_report
from evaluation.suite import SKEvaluationSuite
from quantization.quantizer import SKQuantizer
from model.tensor_backend import SKMatrix


def handle_bridge_command(action: str, payload: dict) -> dict:
    ai = SKAI(workspace_root=ROOT_DIR, offline_mode=bool(payload.get("offline_mode", True)))

    if action == "status":
        hw = ai.get_hardware_status()
        storage = generate_storage_report()
        smoke = run_smoke_test()
        quant_comp = SKQuantizer.compare_all_formats(SKMatrix(64, 64, seed=42))
        return {
            "ok": True,
            "hardware": hw,
            "storage": storage,
            "smoke": smoke,
            "quantization_comparison": quant_comp,
            "offline_mode": ai.offline_mode,
        }
    if action == "chat":
        return {"ok": True, "result": ai.chat(payload.get("prompt", "Explain quantum computing in Sinhala."))}
    if action == "code":
        return {
            "ok": True,
            "result": ai.generate_code(
                prompt=payload.get("prompt", "Write a Python task processor"),
                language=payload.get("language"),
            ),
        }
    if action == "image":
        return {
            "ok": True,
            "result": ai.generate_image(
                prompt=payload.get("prompt", "Calm ocean horizon in Sri Lanka"),
                negative_prompt=payload.get("negative_prompt", ""),
                width=int(payload.get("width", 160)),
                height=int(payload.get("height", 160)),
                steps=int(payload.get("steps", 12)),
                guidance_scale=float(payload.get("guidance_scale", 7.5)),
                seed=int(payload.get("seed", 42)),
            ),
        }
    if action == "music":
        return {
            "ok": True,
            "result": ai.generate_music(
                prompt=payload.get("prompt", "Create a happy Sinhala pop song"),
                duration_sec=float(payload.get("duration_sec", 3.5)),
                transform_style=payload.get("transform_style"),
                tempo_multiplier=float(payload.get("tempo_multiplier", 1.0)),
            ),
        }
    if action == "video":
        return {
            "ok": True,
            "result": ai.generate_video(
                prompt=payload.get("prompt", "Sunrise over Sri Lanka highlands"),
                duration_sec=float(payload.get("duration_sec", 1.5)),
                fps=int(payload.get("fps", 4)),
                seed=int(payload.get("seed", 42)),
                mode=payload.get("mode", "text_to_video"),
            ),
        }
    if action == "speech":
        return {"ok": True, "result": ai.synthesize_speech(text=payload.get("text", "Ayubowan SK AI"))}
    if action == "android":
        return {
            "ok": True,
            "result": ai.create_android_project(
                prompt=payload.get("prompt", "Create a Sinhala AI chat app."),
                project_name=payload.get("project_name", "SKAISinhalaChat"),
            ),
        }
    if action == "windows":
        return {
            "ok": True,
            "result": ai.create_windows_project(
                prompt=payload.get("prompt", "Make this HTML app into a Windows EXE."),
                project_name=payload.get("project_name", "SKAIDesktopApp"),
                stack=payload.get("stack"),
            ),
        }
    if action == "workspace":
        fs = ai.orchestrator.tools["filesystem"]
        return {"ok": True, "result": fs.list_workspace(payload.get("dir", "."))}
    if action == "evaluate":
        suite = SKEvaluationSuite(workspace_root=ROOT_DIR)
        return {"ok": True, "result": suite.run_all_evaluations()}
    if action == "memory_add":
        return {
            "ok": True,
            "result": ai.orchestrator.memory.store_memory(
                text=payload.get("text", ""),
                category=payload.get("category", "preference"),
                user_approved=True,
            ),
        }
    if action == "memory_list":
        return {"ok": True, "result": ai.orchestrator.memory.vector_store.records}
    if action == "memory_clear":
        return {"ok": True, "result": ai.orchestrator.memory.reset_all_memory()}

    return {"ok": False, "error": f"Unknown bridge action '{action}'"}


if __name__ == "__main__":
    raw_in = sys.stdin.read().strip()
    req = json.loads(raw_in) if raw_in else {"action": "status", "payload": {}}
    out = handle_bridge_command(req.get("action", "status"), req.get("payload", {}))
    sys.stdout.write(json.dumps(out, ensure_ascii=False))
