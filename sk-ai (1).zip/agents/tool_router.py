"""
AgentToolRouter: Maps planned agent steps to registered tools in `tools/`.
"""

from typing import Dict, Any, List


class AgentToolRouter:
    AVAILABLE_TOOLS = [
        "filesystem", "python", "shell", "git", "android",
        "build", "web", "image", "audio", "video"
    ]

    def select_tools(self, task_description: str) -> List[str]:
        desc = task_description.lower()
        selected: List[str] = []
        mapping = {
            "file": "filesystem",
            "directory": "filesystem",
            "python": "python",
            "shell": "shell",
            "command": "shell",
            "git": "git",
            "android": "android",
            "gradle": "android",
            "build": "build",
            "compile": "build",
            "web": "web",
            "http": "web",
            "image": "image",
            "audio": "audio",
            "music": "audio",
            "video": "video",
        }
        for key, tool_name in mapping.items():
            if key in desc and tool_name not in selected:
                selected.append(tool_name)
        return selected
