"""
SK AI Bilingual & Code Tokenizer Package (Sinhala + English + Programming Languages).
"""

from .sk_tokenizer import SKTokenizer

__all__ = ["SKTokenizer"]
