"""
SK-SPEECH Subsystem (`speech/`).
Provides local Formant Text-to-Speech (TTS) WAV synthesis and Speech-to-Text (STT) pipeline.
"""

from .speech_model import SKSpeechModel

__all__ = ["SKSpeechModel"]
