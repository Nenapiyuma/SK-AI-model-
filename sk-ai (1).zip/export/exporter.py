"""
SK AI Model Exporter (`export/`).
Exports SK-LLM models to portable binary checkpoints with JSON architecture manifests.
"""

import os
import json
from typing import Dict, Any
from model.llm import SKLLMForCausalLM


class SKModelExporter:
    @staticmethod
    def export_model(model: SKLLMForCausalLM, output_dir: str) -> Dict[str, Any]:
        os.makedirs(output_dir, exist_ok=True)
        weights_path = os.path.join(output_dir, f"{model.config.variant_id}.skbin")
        manifest_path = os.path.join(output_dir, "export_manifest.json")
        ckpt_meta = model.save_checkpoint(weights_path)
        manifest = {
            "format": "SKAI_PORTABLE_V1",
            "config": model.config.to_dict(),
            "checkpoint": ckpt_meta,
        }
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)
        return manifest
