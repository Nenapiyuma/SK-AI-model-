"""
SKTokenizer: Hybrid Subword + Sinhala Unicode + Byte-Fallback Tokenizer.
Supports lossless encoding/decoding across Sinhala (සිංහල), English, Sinhala-English code-switching,
and 16+ programming languages with chat templates and special control tokens.
"""

import json
import os
import re
import hashlib
from typing import List, Dict, Optional, Any


SPECIAL_TOKENS = [
    "<|pad|>",
    "<|bos|>",
    "<|eos|>",
    "<|unk|>",
    "<|system|>",
    "<|user|>",
    "<|assistant|>",
    "<|tool_call|>",
    "<|tool_result|>",
    "<|code|>",
    "<|sinhala|>",
    "<|english|>",
]

COMMON_SINHALA_TOKENS = [
    "ආයුබෝවන්", "සිංහල", "ශ්‍රී", "ලංකා", "පරිගණක", "විද්‍යාව", "කෘත්‍රිම", "බුද්ධිය",
    "ක්වොන්ටම්", "ගණනය", "පද්ධතිය", "මෘදුකාංග", "කේතය", "ගීතය", "සංගීතය", "වීඩියෝ",
    "රූපය", "යෙදුම", "දුරකථන", "වින්ඩෝස්", "ඇන්ඩ්‍රොයිඩ්", "දත්ත", "ගොනුව", "විශ්ලේෂණය",
    "ප්‍රශ්නය", "පිළිතුර", "පැහැදිලි", "කරන්න", "සාදන්න", "භාෂාව", "ඉංග්‍රීසි", "තාක්ෂණය",
    "මතකය", "ආරක්ෂාව", "පරීක්ෂණය", "සාර්ථකයි", "දෝෂය", "ගොඩනැගීම", "ක්‍රියාත්මක",
    "හා", "සහ", "සඳහා", "මෙම", "එය", "අපි", "ඔබ", "මම", "නව", "හොඳ", "සතුටු", "පොප්",
]

COMMON_ENGLISH_AND_CODE_TOKENS = [
    "the", "and", "for", "with", "that", "this", "from", "have", "are", "not",
    "function", "return", "const", "let", "var", "import", "export", "default",
    "class", "def", "self", "async", "await", "try", "except", "finally", "raise",
    "public", "private", "static", "void", "int", "float", "string", "boolean",
    "fun", "val", "override", "Composable", "Modifier", "Column", "Row", "Text",
    "Button", "Scaffold", "AndroidManifest", "gradle", "package", "struct", "impl",
    "fn", "mut", "pub", "use", "SELECT", "FROM", "WHERE", "INSERT", "UPDATE",
    "quantum", "computing", "qubit", "superposition", "entanglement", "algorithm",
    "neural", "network", "transformer", "attention", "model", "local", "offline",
]


class SKTokenizer:
    """
    Lossless Multilingual (Sinhala + English + Code) Tokenizer with Byte-Level Fallback.
    """

    def __init__(self, vocab_size: int = 4096):
        self.vocab_size = vocab_size
        self.token_to_id: Dict[str, int] = {}
        self.id_to_token: Dict[int, str] = {}
        self._build_vocab()

    def _build_vocab(self) -> None:
        idx = 0
        # 1. Special tokens (0..11)
        for sp in SPECIAL_TOKENS:
            self.token_to_id[sp] = idx
            self.id_to_token[idx] = sp
            idx += 1

        # 2. 256 byte-fallback tokens (<0x00> .. <0xFF>) for 100% lossless round-trip
        self.byte_offset = idx
        for b in range(256):
            tok = f"<0x{b:02X}>"
            self.token_to_id[tok] = idx
            self.id_to_token[idx] = tok
            idx += 1

        # 3. Sinhala Unicode block characters U+0D80 .. U+0DFF
        for cp in range(0x0D80, 0x0E00):
            ch = chr(cp)
            if ch not in self.token_to_id and idx < self.vocab_size:
                self.token_to_id[ch] = idx
                self.id_to_token[idx] = ch
                idx += 1

        # 4. Common Sinhala words & morphemes
        for word in COMMON_SINHALA_TOKENS:
            for variant in (word, " " + word):
                if variant not in self.token_to_id and idx < self.vocab_size:
                    self.token_to_id[variant] = idx
                    self.id_to_token[idx] = variant
                    idx += 1

        # 5. Common English & programming tokens
        for word in COMMON_ENGLISH_AND_CODE_TOKENS:
            for variant in (word, " " + word):
                if variant not in self.token_to_id and idx < self.vocab_size:
                    self.token_to_id[variant] = idx
                    self.id_to_token[idx] = variant
                    idx += 1

        # 6. Printable ASCII characters & whitespace
        for cp in range(32, 127):
            ch = chr(cp)
            if ch not in self.token_to_id and idx < self.vocab_size:
                self.token_to_id[ch] = idx
                self.id_to_token[idx] = ch
                idx += 1

        # 7. Fill remaining vocabulary slots up to vocab_size with deterministic subwords
        while idx < self.vocab_size:
            tok = f"<|subword_{idx}|>"
            self.token_to_id[tok] = idx
            self.id_to_token[idx] = tok
            idx += 1

    @property
    def pad_token_id(self) -> int:
        return self.token_to_id["<|pad|>"]

    @property
    def bos_token_id(self) -> int:
        return self.token_to_id["<|bos|>"]

    @property
    def eos_token_id(self) -> int:
        return self.token_to_id["<|eos|>"]

    def detect_script(self, text: str) -> str:
        """Detects whether input text is Sinhala ('si'), English ('en'), or Mixed ('si-en')."""
        has_si = any(0x0D80 <= ord(ch) <= 0x0DFF for ch in text)
        has_en = any(("a" <= ch.lower() <= "z") for ch in text)
        if has_si and has_en:
            return "si-en"
        if has_si:
            return "si"
        return "en"

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        ids: List[int] = []
        if add_special_tokens:
            ids.append(self.bos_token_id)

        # Split keeping leading spaces attached to words where possible
        pattern = re.compile(r"(<\|[a-z_]+\|>| ?[\u0D80-\u0DFF]+| ?[A-Za-z_][A-Za-z0-9_]*|\s+|.)")
        pieces = pattern.findall(text)
        for piece in pieces:
            if piece in self.token_to_id:
                ids.append(self.token_to_id[piece])
            else:
                # Try character by character, falling back to UTF-8 bytes
                for ch in piece:
                    if ch in self.token_to_id:
                        ids.append(self.token_to_id[ch])
                    else:
                        for b in ch.encode("utf-8"):
                            ids.append(self.byte_offset + b)

        if add_special_tokens:
            ids.append(self.eos_token_id)
        return ids

    def decode(self, token_ids: List[int], skip_special_tokens: bool = True) -> str:
        special_set = set(SPECIAL_TOKENS)
        out_parts: List[str] = []
        pending_bytes = bytearray()

        def flush_bytes() -> None:
            if pending_bytes:
                out_parts.append(pending_bytes.decode("utf-8", errors="replace"))
                pending_bytes.clear()

        for tid in token_ids:
            tok = self.id_to_token.get(tid, "<|unk|>")
            if skip_special_tokens and tok in special_set:
                continue
            if tok.startswith("<0x") and tok.endswith(">") and len(tok) == 6:
                pending_bytes.append(int(tok[3:5], 16))
            else:
                flush_bytes()
                out_parts.append(tok)

        flush_bytes()
        return "".join(out_parts)

    def apply_chat_template(self, messages: List[Dict[str, str]]) -> str:
        formatted = []
        for msg in messages:
            role = msg.get("role", "user").lower()
            content = msg.get("content", "")
            if role == "system":
                formatted.append(f"<|system|>{content}<|eos|>")
            elif role == "assistant":
                formatted.append(f"<|assistant|>{content}<|eos|>")
            else:
                formatted.append(f"<|user|>{content}<|eos|>")
        formatted.append("<|assistant|>")
        return "".join(formatted)

    def save(self, filepath: str) -> Dict[str, Any]:
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        payload = json.dumps(
            {
                "tokenizer_type": "SKTokenizer_BPE_Sinhala_English_V1",
                "vocab_size": self.vocab_size,
                "special_tokens": SPECIAL_TOKENS,
                "token_to_id": self.token_to_id,
            },
            ensure_ascii=False,
            indent=2,
        ).encode("utf-8")
        with open(filepath, "wb") as f:
            f.write(payload)
        return {
            "filepath": filepath,
            "file_size": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "vocab_size": self.vocab_size,
        }
