"""
FilesystemTool: Sandboxed local workspace file inspection and confirmation-gated modification.
"""

import os
from typing import Dict, Any, List


class FilesystemTool:
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = os.path.abspath(workspace_root)

    def _resolve_safe_path(self, rel_path: str) -> str:
        candidate = os.path.abspath(os.path.join(self.workspace_root, rel_path))
        if not candidate.startswith(self.workspace_root):
            raise PermissionError(f"Sandbox violation: path '{rel_path}' escapes workspace root.")
        return candidate

    def list_workspace(self, rel_dir: str = ".") -> Dict[str, Any]:
        target = self._resolve_safe_path(rel_dir)
        if not os.path.exists(target):
            return {"exists": False, "entries": []}
        entries: List[Dict[str, Any]] = []
        for name in sorted(os.listdir(target)):
            if name.startswith(".") or name == "node_modules" or name == "__pycache__":
                continue
            full = os.path.join(target, name)
            entries.append(
                {
                    "name": name,
                    "type": "dir" if os.path.isdir(full) else "file",
                    "size_bytes": os.path.getsize(full) if os.path.isfile(full) else 0,
                }
            )
        return {"exists": True, "directory": rel_dir, "entries": entries}

    def read_file(self, rel_path: str, max_bytes: int = 32768) -> Dict[str, Any]:
        target = self._resolve_safe_path(rel_path)
        if not os.path.isfile(target):
            return {"exists": False, "error": f"File '{rel_path}' does not exist."}
        with open(target, "r", encoding="utf-8", errors="replace") as f:
            content = f.read(max_bytes)
        return {"exists": True, "path": rel_path, "content": content, "size_bytes": os.path.getsize(target)}

    def delete_file(self, rel_path: str, user_confirmed: bool = False) -> Dict[str, Any]:
        if not user_confirmed:
            return {
                "deleted": False,
                "requires_confirmation": True,
                "error": "Destructive operation blocked: deleting files requires `user_confirmed=True`.",
            }
        target = self._resolve_safe_path(rel_path)
        if os.path.isfile(target):
            os.remove(target)
            return {"deleted": True, "path": rel_path}
        return {"deleted": False, "error": "File does not exist."}
