"""
SKMusicExporter: Packages generated WAV, MIDI, Stems, and Rights-Aware Documentation.
"""

from typing import Dict, Any


COPYRIGHT_NOTICE = (
    "SK-MUSIC Rights & Copyright Notice: SK AI is strictly prohibited from cloning the distinctive "
    "voice of any living artist or reproducing copyrighted compositions. Generated audio and MIDI "
    "arrangements are synthesized algorithmically; SK AI does not provide legal advice or guarantee "
    "that any generated output is legally copyright-free in all jurisdictions."
)


class SKMusicExporter:
    @staticmethod
    def package_export(
        composition: Dict[str, Any],
        midi_info: Dict[str, Any],
        wav_info: Dict[str, Any],
        stem_paths: Dict[str, str],
    ) -> Dict[str, Any]:
        return {
            "subsystem": "SK-MUSIC",
            "style": composition["style"],
            "tempo_bpm": composition["tempo_bpm"],
            "scale": composition["scale"],
            "instrumentation": composition["instrumentation"],
            "chord_progression": [c["name"] for c in composition["chord_progression"]],
            "midi_path": midi_info["midi_path"],
            "midi_size_bytes": midi_info["file_size_bytes"],
            "wav_path": wav_info["wav_path"],
            "wav_size_bytes": wav_info["file_size_bytes"],
            "audio_data_url": wav_info["data_url"],
            "stems": stem_paths,
            "copyright_notice": COPYRIGHT_NOTICE,
        }
