"""
SKTestRunner: Executes automated Python test suites and captures structured results.
"""

import subprocess
import sys
import time
from typing import Dict, Any, Optional


class SKTestRunner:
    @staticmethod
    def run_python_test_file(test_path: str, timeout_sec: int = 30) -> Dict[str, Any]:
        t0 = time.perf_counter()
        try:
            proc = subprocess.run(
                [sys.executable, test_path],
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
            return {
                "passed": proc.returncode == 0,
                "returncode": proc.returncode,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "duration_ms": round((time.perf_counter() - t0) * 1000.0, 2),
            }
        except Exception as e:
            return {
                "passed": False,
                "returncode": -1,
                "error": str(e),
                "duration_ms": round((time.perf_counter() - t0) * 1000.0, 2),
            }
