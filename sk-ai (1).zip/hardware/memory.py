"""
System RAM & Swap Memory Inspector.
Reads actual Linux `/proc/meminfo` or OS fallbacks.
"""

import os
from typing import Dict, Any


class MemoryInspector:
    @staticmethod
    def get_system_memory() -> Dict[str, Any]:
        total_kb = 0
        available_kb = 0
        free_kb = 0
        if os.path.exists("/proc/meminfo"):
            try:
                with open("/proc/meminfo", "r", encoding="utf-8") as f:
                    for line in f:
                        parts = line.split(":")
                        if len(parts) == 2:
                            key = parts[0].strip()
                            val_str = parts[1].strip().split()[0]
                            if key == "MemTotal":
                                total_kb = int(val_str)
                            elif key == "MemAvailable":
                                available_kb = int(val_str)
                            elif key == "MemFree":
                                free_kb = int(val_str)
            except Exception:
                pass

        if total_kb == 0:
            # Fallback if /proc/meminfo is inaccessible
            total_kb = 8 * 1024 * 1024
            available_kb = 4 * 1024 * 1024

        if available_kb == 0:
            available_kb = free_kb

        total_bytes = total_kb * 1024
        available_bytes = available_kb * 1024
        used_bytes = max(0, total_bytes - available_bytes)
        return {
            "total_bytes": total_bytes,
            "available_bytes": available_bytes,
            "used_bytes": used_bytes,
            "total_gb": round(total_bytes / (1024**3), 2),
            "available_gb": round(available_bytes / (1024**3), 2),
            "used_gb": round(used_bytes / (1024**3), 2),
            "percent_used": round((used_bytes / max(1, total_bytes)) * 100.0, 1),
        }
