"""
SKMusicModel: Main entry point for SK-MUSIC with strict anti-voice-cloning and copyright guardrails.
"""

from typing import Dict, Any, Optional
from .composer import SKMusicComposer
from .arranger import SKMusicArranger
from .midi_generator import SKMidiGenerator
from .audio_generator import SKMusicAudioGenerator
from .stems import SKStemProcessor
from .exporter import SKMusicExporter, COPYRIGHT_NOTICE


BANNED_CLONING_KEYWORDS = [
    "clone voice of",
    "sound exactly like artist",
    "copy copyrighted song",
    "impersonate singer",
]


class SKMusicModel:
    def __init__(self):
        self.composer = SKMusicComposer()
        self.arranger = SKMusicArranger()
        self.midi_gen = SKMidiGenerator()
        self.audio_gen = SKMusicAudioGenerator()
        self.stem_proc = SKStemProcessor()
        self.exporter = SKMusicExporter()

    def generate_music(
        self,
        prompt: str,
        duration_sec: float = 3.5,
        transform_style: Optional[str] = None,
        tempo_multiplier: float = 1.0,
        output_prefix: str = "models/weights/sk_music",
    ) -> Dict[str, Any]:
        p_lower = prompt.lower()
        for banned in BANNED_CLONING_KEYWORDS:
            if banned in p_lower:
                return {
                    "subsystem": "SK-MUSIC",
                    "blocked_by_copyright_policy": True,
                    "error": (
                        "Request refused: SK AI does not clone living artists' voices or reproduce "
                        "copyrighted songs. Please describe an original musical style, mood, or arrangement."
                    ),
                    "copyright_notice": COPYRIGHT_NOTICE,
                }

        comp = self.composer.compose(prompt=prompt, duration_sec=duration_sec)
        if transform_style or tempo_multiplier != 1.0:
            comp = self.arranger.transform_arrangement(
                comp,
                target_style=transform_style or comp["style"],
                tempo_multiplier=tempo_multiplier,
            )

        midi_info = self.midi_gen.write_midi(comp, output_path=f"{output_prefix}.mid")
        wav_info = self.audio_gen.render_wav(comp, output_path=f"{output_prefix}.wav")
        stems = self.stem_proc.export_stems(
            wav_info["_stems_buffers"], output_dir=f"{output_prefix}_stems"
        )
        return self.exporter.package_export(comp, midi_info, wav_info, stems)
