"""
GPU & VRAM Detection Subsystem.
Queries `nvidia-smi` and PyTorch CUDA/MPS backends honestly without fabricating GPU hardware.
"""

import subprocess
import shutil
from typing import Dict, Any, List


class GPUDetector:
    @staticmethod
    def detect_gpus() -> Dict[str, Any]:
        gpus: List[Dict[str, Any]] = []
        cuda_available = False
        mps_available = False
        total_vram_mb = 0

        # 1. Check nvidia-smi if present
        nvidia_smi = shutil.which("nvidia-smi")
        if nvidia_smi:
            try:
                proc = subprocess.run(
                    [
                        nvidia_smi,
                        "--query-gpu=index,name,memory.total,memory.free,memory.used",
                        "--format=csv,noheader,nounits",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=3,
                )
                if proc.returncode == 0 and proc.stdout.strip():
                    cuda_available = True
                    for line in proc.stdout.strip().splitlines():
                        parts = [p.strip() for p in line.split(",")]
                        if len(parts) >= 5:
                            vram_tot = int(float(parts[2]))
                            vram_free = int(float(parts[3]))
                            vram_used = int(float(parts[4]))
                            total_vram_mb += vram_tot
                            gpus.append(
                                {
                                    "index": int(parts[0]),
                                    "name": parts[1],
                                    "vram_total_mb": vram_tot,
                                    "vram_free_mb": vram_free,
                                    "vram_used_mb": vram_used,
                                    "vram_total_gb": round(vram_tot / 1024.0, 2),
                                }
                            )
            except Exception:
                pass

        # 2. Check torch if installed and nvidia-smi didn't already populate
        if not gpus:
            try:
                import torch  # type: ignore

                if torch.cuda.is_available():
                    cuda_available = True
                    for idx in range(torch.cuda.device_count()):
                        props = torch.cuda.get_device_properties(idx)
                        vram_mb = int(props.total_memory // (1024 * 1024))
                        total_vram_mb += vram_mb
                        gpus.append(
                            {
                                "index": idx,
                                "name": props.name,
                                "vram_total_mb": vram_mb,
                                "vram_free_mb": vram_mb,
                                "vram_used_mb": 0,
                                "vram_total_gb": round(vram_mb / 1024.0, 2),
                            }
                        )
                elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                    mps_available = True
            except ImportError:
                pass

        acceleration = "CUDA" if cuda_available else ("MPS" if mps_available else "CPU")
        return {
            "gpu_available": len(gpus) > 0 or mps_available,
            "cuda_available": cuda_available,
            "mps_available": mps_available,
            "gpu_count": len(gpus),
            "gpus": gpus,
            "total_vram_mb": total_vram_mb,
            "total_vram_gb": round(total_vram_mb / 1024.0, 2),
            "supported_acceleration": acceleration,
        }
