"""
Comprehensive Automated Test Suite for SK AI (`tests/test_skai.py`).
Tests:
1. Model (`SKLLMForCausalLM`, `RMSNorm`, `RotaryEmbedding`, `SwiGLUMLP`, `GroupedQueryAttention`, `KVCache`)
2. Tokenizer (`SKTokenizer` Sinhala + English + Code round-trip & script detection)
3. Inference (`SKInferenceEngine` forward pass & KV cache growth)
4. Router (`SKModelRouter` multimodal & tool routing)
5. Tools & Security (`FilesystemTool`, `ShellTool`, `PythonTool`, `WebTool` offline_mode & confirmation gates)
6. Model Registry & Model Manager (`SKModelManager` SHA-256 verification & storage summary)
7. Hardware Detection & Compatibility (`HardwareDetector`, `HardwareCompatibilityChecker`)
8. Coding System (`SKCodeModel`, `SKBuildAnalyzer`, `SKCodePatcher`)
9. Project Generators (`SKAndroidGenerator`, `SKWindowsGenerator`)
10. Multimodal Subsystems (`SKMusicModel` + copyright policy, `SKImagePipeline`, `SKVideoModel`, `SKSpeechModel`, `SKMemoryManager`, `SKQuantizer`)
"""

import os
import sys
import unittest

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from model.config import get_model_config
from model.llm import SKLLMForCausalLM
from tokenizer.sk_tokenizer import SKTokenizer
from inference.engine import SKInferenceEngine
from router.model_router import SKModelRouter
from tools import get_tool_registry
from model_manager.manager import SKModelManager
from hardware.detect import HardwareDetector
from hardware.compatibility import HardwareCompatibilityChecker
from coding.code_model import SKCodeModel
from coding.patcher import SKCodePatcher
from android.generator import SKAndroidGenerator
from windows.generator import SKWindowsGenerator
from music.music_model import SKMusicModel
from image.pipeline import SKImagePipeline
from video.video_model import SKVideoModel
from speech.speech_model import SKSpeechModel
from memory.memory_manager import SKMemoryManager
from quantization.quantizer import SKQuantizer
from model.tensor_backend import SKMatrix
from core.skai import SKAI


class TestSKAI(unittest.TestCase):
    def test_01_model_architecture_and_forward(self):
        cfg = get_model_config("sk-llm-mini")
        model = SKLLMForCausalLM(cfg)
        self.assertEqual(model.num_parameters(), cfg.estimate_parameter_count())
        kv = model.create_kv_cache()
        out = model.forward([1, 45, 89], kv_cache=kv, start_pos=0)
        self.assertEqual(len(out["logits"]), cfg.vocab_size)
        self.assertEqual(kv.seq_len(0), 3)

    def test_02_tokenizer_sinhala_english_code_roundtrip(self):
        tok = SKTokenizer(vocab_size=4096)
        samples = [
            "ආයුබෝවන්! සිංහල සහ English mixed text.",
            "def compute_attention(q, k, v):\n    return softmax(q @ k.T) @ v",
            "ක්වොන්ටම් පරිගණනය (Quantum Computing) 2026",
        ]
        for s in samples:
            ids = tok.encode(s, add_special_tokens=True)
            decoded = tok.decode(ids, skip_special_tokens=True)
            self.assertEqual(decoded, s)
        self.assertEqual(tok.detect_script("ආයුබෝවන්"), "si")
        self.assertEqual(tok.detect_script("Hello world"), "en")
        self.assertEqual(tok.detect_script("ආයුබෝවන් Hello"), "si-en")

    def test_03_inference_engine(self):
        eng = SKInferenceEngine(variant="sk-llm-mini")
        res = eng.generate("Explain quantum computing in Sinhala.", max_new_tokens=6)
        self.assertIn("ක්වොන්ටම්", res["text"])
        self.assertGreater(res["trace"]["kv_cache_seq_len"], 3)

    def test_04_model_router(self):
        router = SKModelRouter()
        self.assertIn("SK-LLM", router.route("What is gravity?")["models"])
        self.assertIn("SK-CODE", router.route("Refactor this Python function")["models"])
        self.assertIn("SK-VISION", router.route("Explain this screenshot", has_image_input=True)["models"])
        self.assertIn("SK-MUSIC", router.route("Create a happy Sinhala pop song")["models"])
        self.assertIn("SK-VIDEO", router.route("Generate video of waves")["models"])
        self.assertEqual(router.route("Create an Android Studio Jetpack Compose app")["intent"], "android_development")

    def test_05_tools_and_security_boundaries(self):
        tools = get_tool_registry(workspace_root=ROOT_DIR, offline_mode=True)
        # Destructive shell command must be blocked even if confirmed
        rm_res = tools["shell"].run("rm -rf /", user_confirmed=True)
        self.assertTrue(rm_res.get("blocked"))
        # Unconfirmed non-readonly command must require confirmation
        unconf = tools["shell"].run("echo hello", user_confirmed=False)
        self.assertTrue(unconf.get("requires_confirmation"))
        # Offline mode blocks web tool
        web_res = tools["web"].fetch("https://example.com")
        self.assertTrue(web_res.get("blocked_by_offline_mode"))
        # File deletion requires confirmation
        del_res = tools["filesystem"].delete_file("README.md", user_confirmed=False)
        self.assertTrue(del_res.get("requires_confirmation"))

    def test_06_model_registry_and_manager(self):
        mm = SKModelManager(workspace_root=ROOT_DIR)
        models = mm.list_models()
        self.assertGreaterEqual(len(models), 10)
        verify = mm.verify_sha256("sk-llm-mini")
        self.assertTrue(verify["verified"])
        not_inst = mm.select_active_model("sk-llm-large")
        self.assertFalse(not_inst["selected"])
        self.assertEqual(not_inst["status"], "NOT INSTALLED")

    def test_07_hardware_detection_and_compatibility(self):
        hw = HardwareDetector.detect_all(ROOT_DIR)
        self.assertGreater(hw["cpu"]["logical_cores"], 0)
        self.assertGreater(hw["memory"]["total_bytes"], 0)
        compat = HardwareCompatibilityChecker.check_model_compatibility(
            "SK-VIDEO-14B", required_ram_gb=128.0, required_vram_gb=80.0, requires_gpu=True
        )
        self.assertGreater(len(compat["warnings"]), 0)

    def test_08_coding_subsystem(self):
        cm = SKCodeModel()
        for lang in ["Python", "TypeScript", "Kotlin", "Rust", "C++", "SQL"]:
            gen = cm.generate_code(f"Create sample in {lang}", language=lang)
            self.assertEqual(gen["language"], lang)
            self.assertTrue(len(gen["code"]) > 20)
        bad_debug = cm.debug_code("def broken_func(\n")
        self.assertFalse(bad_debug["valid"])
        patch_gate = SKCodePatcher.apply_replacement("README.md", "a", "b", user_confirmed=False)
        self.assertTrue(patch_gate.get("requires_confirmation"))

    def test_09_android_and_windows_project_generators(self):
        ag = SKAndroidGenerator()
        and_res = ag.create_android_project(
            prompt="Create a Sinhala AI chat app.",
            output_dir=os.path.join(ROOT_DIR, "generated_projects", "test_android"),
        )
        self.assertIn("app/src/main/AndroidManifest.xml", and_res["files_created"])
        wg = SKWindowsGenerator()
        win_res = wg.create_windows_project(
            prompt="Make this HTML app into a Windows EXE.",
            output_dir=os.path.join(ROOT_DIR, "generated_projects", "test_windows"),
        )
        self.assertFalse(win_res["exe_binary_compiled"])
        self.assertGreater(len(win_res["files_created"]), 2)

    def test_10_multimodal_music_image_video_quantization_memory(self):
        # Music + copyright guardrail
        mus = SKMusicModel()
        blocked = mus.generate_music("Please clone voice of living singer")
        self.assertTrue(blocked.get("blocked_by_copyright_policy"))
        ok_song = mus.generate_music("Create a happy Sinhala pop song", duration_sec=1.0)
        self.assertTrue(os.path.exists(ok_song["midi_path"]))
        self.assertTrue(os.path.exists(ok_song["wav_path"]))

        # Image
        img = SKImagePipeline().run("Emerald tea hills", width=48, height=48, steps=4)
        self.assertTrue(os.path.exists(img["output_path"]))

        # Quantization
        q_comp = SKQuantizer.compare_all_formats(SKMatrix(32, 32, seed=7))
        self.assertEqual(len(q_comp), 5)

        # Memory
        mem = SKMemoryManager(store_path=os.path.join(ROOT_DIR, "memory", "test_vectors.json"))
        mem.reset_all_memory()
        st = mem.store_memory("Sinhala language uses Unicode block 0D80-0DFF", category="document")
        self.assertTrue(st["stored"])
        hits = mem.query_memory("Sinhala Unicode")
        self.assertGreaterEqual(len(hits), 1)
        mem.reset_all_memory()


if __name__ == "__main__":
    unittest.main(verbosity=2)
