"""
VideoFrameProcessor: Renders temporally coherent RGB frames and encodes them as base64 PNG frames.
"""

import math
import base64
from typing import List, Dict, Any
from image.conditioning import PromptConditioner
from image.sampler import encode_rgb_to_png_bytes
from .temporal import TemporalConsistencyEngine


class VideoFrameProcessor:
    def __init__(self):
        self.conditioner = PromptConditioner()
        self.temporal = TemporalConsistencyEngine()

    def render_frames(
        self,
        prompt: str,
        num_frames: int = 6,
        width: int = 128,
        height: int = 96,
        seed: int = 42,
    ) -> List[Dict[str, Any]]:
        cond = self.conditioner.encode_prompt(prompt)
        trajectories = self.temporal.compute_frame_trajectories(num_frames, seed=seed)
        r1, g1, b1 = cond["primary_rgb"]
        r2, g2, b2 = cond["secondary_rgb"]
        fx, fy = cond["freq_x"], cond["freq_y"]

        frames_out: List[Dict[str, Any]] = []
        for traj in trajectories:
            f_idx = int(traj["frame_index"])
            pan_x = traj["pan_x"]
            pan_y = traj["pan_y"]
            zoom = traj["zoom"]
            buf = bytearray(width * height * 3)
            pos = 0
            for y in range(height):
                ny = ((y / max(1, height - 1)) - 0.5) / zoom + 0.5 + pan_y
                for x in range(width):
                    nx = ((x / max(1, width - 1)) - 0.5) / zoom + 0.5 + pan_x
                    wave = 0.5 + 0.5 * math.sin(nx * math.pi * fx + f_idx * 0.45) * math.cos(
                        ny * math.pi * fy - f_idx * 0.35
                    )
                    orb_dist = math.sqrt((nx - (0.5 + pan_x * 1.2)) ** 2 + (ny - (0.5 + pan_y * 1.2)) ** 2)
                    orb = max(0.0, 1.0 - orb_dist * 3.2)
                    buf[pos] = max(0, min(255, int(r1 * (1.0 - wave) + r2 * wave + 75.0 * orb)))
                    buf[pos + 1] = max(0, min(255, int(g1 * (1.0 - wave) + g2 * wave + 65.0 * orb)))
                    buf[pos + 2] = max(0, min(255, int(b1 * (1.0 - wave) + b2 * wave + 85.0 * orb)))
                    pos += 3

            png_bytes = encode_rgb_to_png_bytes(width, height, bytes(buf))
            frames_out.append(
                {
                    "frame_index": f_idx,
                    "png_bytes": png_bytes,
                    "data_url": "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii"),
                    "trajectory": traj,
                }
            )
        return frames_out
