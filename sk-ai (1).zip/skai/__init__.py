"""
Top-level `skai` Python package exposing `SKAI` and the `skai` CLI.
"""

from core.skai import SKAI

__all__ = ["SKAI"]
__version__ = "1.0.0"
