"""
BuildTool: Inspects build toolchains (Python, Node/Vite, Gradle, Windows EXE compilers)
without pretending unavailable OS compilers exist.
"""

import shutil
import platform
from typing import Dict, Any


class BuildTool:
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = workspace_root

    def detect_toolchains(self) -> Dict[str, Any]:
        return {
            "os": platform.system(),
            "python3": shutil.which("python3") is not None,
            "node": shutil.which("node") is not None,
            "gradle": shutil.which("gradle") is not None,
            "pyinstaller": shutil.which("pyinstaller") is not None,
            "cargo": shutil.which("cargo") is not None,
            "dotnet": shutil.which("dotnet") is not None,
            "can_build_native_windows_exe_locally": platform.system() == "Windows" and (
                shutil.which("pyinstaller") is not None or shutil.which("dotnet") is not None
            ),
        }
