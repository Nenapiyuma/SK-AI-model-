"""
SK AI Quantization Subsystem (`quantization/`).
Supports FP32, FP16, BF16, INT8, and 4-bit weight quantization and empirically measures
model size, RAM/VRAM footprint, quantization speed, and reconstruction quality (MSE & SNR dB).
"""

from .quantizer import SKQuantizer

__all__ = ["SKQuantizer"]
