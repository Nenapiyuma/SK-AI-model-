"""
TemporalConsistencyEngine: Computes smooth motion vectors and phase-locked latent trajectories
across video frames so sequential frames maintain temporal coherence.
"""

import math
from typing import List, Dict, Any


class TemporalConsistencyEngine:
    @staticmethod
    def compute_frame_trajectories(num_frames: int, seed: int = 42) -> List[Dict[str, float]]:
        trajectories: List[Dict[str, float]] = []
        for f in range(max(1, num_frames)):
            progress = f / max(1, num_frames - 1) if num_frames > 1 else 0.0
            phase = progress * 2.0 * math.pi
            trajectories.append(
                {
                    "frame_index": f,
                    "progress": round(progress, 4),
                    "pan_x": round(0.18 * math.sin(phase), 4),
                    "pan_y": round(0.12 * math.cos(phase), 4),
                    "zoom": round(1.0 + 0.15 * math.sin(phase * 0.5), 4),
                }
            )
        return trajectories
