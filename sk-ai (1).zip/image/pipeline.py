"""
SKImagePipeline: Unified pipeline for Text-to-Image and Image-to-Image generation.
"""

from typing import Dict, Any, Optional
from .image_model import SKImageModel
from .text_to_image import TextToImageGenerator
from .image_to_image import ImageToImageGenerator


class SKImagePipeline:
    def __init__(self):
        self.model = SKImageModel()
        self.txt2img = TextToImageGenerator()
        self.img2img = ImageToImageGenerator()

    def run(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 160,
        height: int = 160,
        steps: int = 12,
        guidance_scale: float = 7.5,
        seed: int = 42,
        mode: str = "text_to_image",
        output_path: str = "models/weights/generated_image.png",
    ) -> Dict[str, Any]:
        if mode == "image_to_image":
            res = self.img2img.generate(prompt=prompt, width=width, height=height, seed=seed, output_path=output_path)
        else:
            res = self.txt2img.generate(
                prompt=prompt,
                negative_prompt=negative_prompt,
                width=width,
                height=height,
                steps=steps,
                guidance_scale=guidance_scale,
                seed=seed,
                output_path=output_path,
            )
        res["model_status"] = self.model.get_status()
        return res
