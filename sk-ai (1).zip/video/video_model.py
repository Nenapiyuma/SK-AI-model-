"""
SKVideoModel: Coordinates SK-VIDEO with mandatory VRAM/GPU hardware inspection and warnings.
Never claims that high-resolution diffusion video generation runs quickly on ordinary hardware.
"""

import os
from typing import Dict, Any
from hardware.compatibility import HardwareCompatibilityChecker
from .text_to_video import TextToVideoPipeline
from .image_to_video import ImageToVideoPipeline
from .video_to_video import VideoToVideoPipeline
from .exporter import SKVideoExporter


class SKVideoModel:
    def __init__(self, weights_dir: str = "models/weights"):
        self.weights_dir = weights_dir
        self.dit_weights_path = os.path.join(weights_dir, "open_video_dit_14b_bf16.safetensors")
        self.txt2vid = TextToVideoPipeline()
        self.img2vid = ImageToVideoPipeline()
        self.vid2vid = VideoToVideoPipeline()
        self.exporter = SKVideoExporter()

    def generate_video(
        self,
        prompt: str,
        duration_sec: float = 1.5,
        fps: int = 4,
        width: int = 128,
        height: int = 96,
        seed: int = 42,
        mode: str = "text_to_video",
        conditioning_image: str = "",
        output_dir: str = "models/weights/video_frames",
    ) -> Dict[str, Any]:
        # Perform mandatory VRAM & hardware check before execution
        hw_check = HardwareCompatibilityChecker.check_model_compatibility(
            model_name="SK-VIDEO (High-Res DiT 14B)",
            required_ram_gb=32.0,
            required_vram_gb=24.0,
            requires_gpu=True,
        )
        dit_installed = os.path.exists(self.dit_weights_path)

        if mode == "image_to_video":
            raw = self.img2vid.generate(prompt, conditioning_image, duration_sec, fps, width, height, seed)
        elif mode == "video_to_video":
            raw = self.vid2vid.generate(prompt, conditioning_image, duration_sec, fps, width, height, seed)
        else:
            raw = self.txt2vid.generate(prompt, duration_sec, fps, width, height, seed)

        exported = self.exporter.export_frame_sequence(raw["frames"], output_dir=output_dir, fps=fps)
        return {
            "subsystem": "SK-VIDEO",
            "mode": raw["mode"],
            "prompt": prompt,
            "fps": fps,
            "duration_sec": duration_sec,
            "resolution": f"{width}x{height}",
            "seed": seed,
            "hardware_check": hw_check,
            "external_dit_weights_status": "INSTALLED"
            if dit_installed
            else "Interface implemented; 14B DiT video weights not installed (using local temporal frame synthesizer).",
            **exported,
        }
