"""
AgentExecutor: Executes planned steps with permission boundary checks.
"""

from typing import Dict, Any, Callable, Optional


class AgentExecutor:
    def __init__(self, tool_registry: Optional[Dict[str, Callable[..., Any]]] = None):
        self.tool_registry = tool_registry or {}

    def execute_step(
        self,
        step: Dict[str, Any],
        context: Dict[str, Any],
        user_confirmed: bool = False,
    ) -> Dict[str, Any]:
        action = step.get("action", "noop")
        if action in self.tool_registry:
            fn = self.tool_registry[action]
            return fn(context=context, user_confirmed=user_confirmed)
        return {
            "step_id": step.get("step_id", 0),
            "action": action,
            "status": "completed",
            "target": step.get("target", "SK-LLM"),
        }
