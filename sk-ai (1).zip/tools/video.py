from typing import Dict, Any


class VideoTool:
    def info(self) -> Dict[str, Any]:
        return {"tool": "video", "subsystem": "SK-VIDEO", "ready": True}
