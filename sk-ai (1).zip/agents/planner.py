"""
AgentPlanner: Decomposes natural-language objectives into ordered execution steps.
"""

from typing import List, Dict, Any


class AgentPlanner:
    def create_plan(self, goal: str, routed_info: Dict[str, Any]) -> List[Dict[str, Any]]:
        intent = routed_info.get("intent", "text_reasoning")
        primary_model = routed_info.get("primary_model", "SK-LLM")
        tools = routed_info.get("tools", [])

        steps: List[Dict[str, Any]] = [
            {
                "step_id": 1,
                "action": "parse_intent_and_context",
                "target": primary_model,
                "description": f"Analyze request under intent '{intent}'.",
            }
        ]
        if tools:
            steps.append(
                {
                    "step_id": 2,
                    "action": "select_and_verify_tools",
                    "target": ",".join(tools),
                    "description": "Validate tool permissions and sandbox constraints.",
                }
            )
        steps.append(
            {
                "step_id": len(steps) + 1,
                "action": "execute_model_pipeline",
                "target": ",".join(routed_info.get("models", [primary_model])),
                "description": "Run local model synthesis.",
            }
        )
        steps.append(
            {
                "step_id": len(steps) + 1,
                "action": "verify_output",
                "target": "verifier",
                "description": "Verify output completeness and safety constraints.",
            }
        )
        return steps
