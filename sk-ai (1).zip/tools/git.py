"""
GitTool: Read-only Git repository inspection tool.
"""

import subprocess
from typing import Dict, Any


class GitTool:
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = workspace_root

    def status(self) -> Dict[str, Any]:
        try:
            proc = subprocess.run(
                ["git", "status", "--short"],
                cwd=self.workspace_root,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return {"ok": proc.returncode == 0, "output": proc.stdout.strip()}
        except Exception as e:
            return {"ok": False, "error": str(e)}
