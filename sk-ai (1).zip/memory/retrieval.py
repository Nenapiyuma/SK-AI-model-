"""
SKRetriever: Chunks text documents and retrieves top-k semantically relevant passages locally.
"""

from typing import List, Dict, Any
from .vector_store import SKVectorStore


class SKRetriever:
    def __init__(self, vector_store: SKVectorStore):
        self.vector_store = vector_store

    def index_document(self, text: str, doc_name: str, chunk_size: int = 300) -> int:
        words = text.split()
        chunks_indexed = 0
        for i in range(0, len(words), max(1, chunk_size // 5)):
            chunk = " ".join(words[i : i + (chunk_size // 5)])
            if chunk.strip():
                self.vector_store.add_record(
                    text=chunk,
                    category="document",
                    metadata={"source": doc_name, "chunk_index": chunks_indexed},
                )
                chunks_indexed += 1
        return chunks_indexed

    def retrieve_context(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        return self.vector_store.search(query, top_k=top_k)
