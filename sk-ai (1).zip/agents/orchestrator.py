"""
AgentOrchestrator: Coordinates Planner -> ToolRouter -> Executor -> Verifier internally
and produces a clean, concise final answer without dumping raw internal chain-of-thought logs.
"""

from typing import Dict, Any, Optional
from .planner import AgentPlanner
from .tool_router import AgentToolRouter
from .executor import AgentExecutor
from .verifier import AgentVerifier
from .memory import AgentWorkingMemory


class AgentOrchestrator:
    def __init__(self):
        self.planner = AgentPlanner()
        self.tool_router = AgentToolRouter()
        self.executor = AgentExecutor()
        self.verifier = AgentVerifier()
        self.memory = AgentWorkingMemory()

    def run_agentic_loop(
        self,
        goal: str,
        routed_info: Dict[str, Any],
        handler_fn: Any,
        expose_internal_trace: bool = False,
    ) -> Dict[str, Any]:
        plan = self.planner.create_plan(goal, routed_info)
        step_results = []
        for step in plan:
            step_results.append(self.executor.execute_step(step, context={"goal": goal}))

        raw_result = handler_fn()
        verification = self.verifier.verify(raw_result)

        # Error-correction retry if initial verification flagged an issue
        if not verification["verified"] and "fallback_text" in raw_result:
            raw_result["text"] = raw_result["fallback_text"]
            verification = self.verifier.verify(raw_result)

        self.memory.add("user", goal, {"intent": routed_info.get("intent")})
        response: Dict[str, Any] = {
            "answer": raw_result.get("text") or raw_result.get("summary") or "Task completed.",
            "result": raw_result,
            "verified": verification["verified"],
        }
        if expose_internal_trace:
            response["_internal_plan"] = plan
            response["_step_results"] = step_results
        return response
