"""
SKCodeAgent: Coordinates code generation, AST inspection, build error analysis, and test execution.
"""

from typing import Dict, Any, Optional
from .code_model import SKCodeModel
from .build_analyzer import SKBuildAnalyzer
from .patcher import SKCodePatcher
from .test_runner import SKTestRunner


class SKCodeAgent:
    def __init__(self):
        self.model = SKCodeModel()
        self.build_analyzer = SKBuildAnalyzer()
        self.patcher = SKCodePatcher()
        self.test_runner = SKTestRunner()

    def handle_coding_task(self, prompt: str, language: Optional[str] = None) -> Dict[str, Any]:
        gen = self.model.generate_code(prompt, language=language)
        analysis = self.model.explain_code(gen["code"])
        return {
            "subsystem": "SK-CODE",
            "language": gen["language"],
            "code": gen["code"],
            "syntax_valid": gen["syntax_valid"],
            "analysis": analysis,
        }
