"""
SK AI Secure Tool Architecture (`tools/`).
Enforces workspace path sandboxing, explicit confirmation gates for destructive operations,
and strict offline_mode compliance.
"""

from .filesystem import FilesystemTool
from .python import PythonTool
from .shell import ShellTool
from .git import GitTool
from .android import AndroidTool
from .build import BuildTool
from .web import WebTool
from .image import ImageTool
from .audio import AudioTool
from .video import VideoTool


def get_tool_registry(workspace_root: str = ".", offline_mode: bool = True):
    return {
        "filesystem": FilesystemTool(workspace_root=workspace_root),
        "python": PythonTool(),
        "shell": ShellTool(workspace_root=workspace_root),
        "git": GitTool(workspace_root=workspace_root),
        "android": AndroidTool(workspace_root=workspace_root),
        "build": BuildTool(workspace_root=workspace_root),
        "web": WebTool(offline_mode=offline_mode),
        "image": ImageTool(),
        "audio": AudioTool(),
        "video": VideoTool(),
    }


__all__ = [
    "FilesystemTool",
    "PythonTool",
    "ShellTool",
    "GitTool",
    "AndroidTool",
    "BuildTool",
    "WebTool",
    "ImageTool",
    "AudioTool",
    "VideoTool",
    "get_tool_registry",
]
