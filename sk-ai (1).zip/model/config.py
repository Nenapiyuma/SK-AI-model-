"""
SK-LLM Configuration System.
Supports SK AI Mini, SK AI Small, SK AI Medium, and SK AI Large tiers.
"""

import json
import os
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional


@dataclass
class SKLLMConfig:
    name: str = "SK AI Mini"
    variant_id: str = "sk-llm-mini"
    vocab_size: int = 4096
    hidden_size: int = 128
    intermediate_size: int = 384
    num_hidden_layers: int = 4
    num_attention_heads: int = 4
    num_key_value_heads: int = 2
    max_position_embeddings: int = 4096
    rms_norm_eps: float = 1e-6
    rope_theta: float = 10000.0
    tie_word_embeddings: bool = True
    use_cache: bool = True
    gradient_checkpointing: bool = False
    dtype: str = "fp32"

    @property
    def head_dim(self) -> int:
        return self.hidden_size // self.num_attention_heads

    @property
    def num_key_value_groups(self) -> int:
        return max(1, self.num_attention_heads // self.num_key_value_heads)

    def estimate_parameter_count(self) -> int:
        """
        Calculates exact architectural parameter count for the Decoder-only Transformer:
        - Embedding: vocab_size * hidden_size
        - Per layer:
          - q_proj: hidden_size * (num_attention_heads * head_dim)
          - k_proj: hidden_size * (num_key_value_heads * head_dim)
          - v_proj: hidden_size * (num_key_value_heads * head_dim)
          - o_proj: (num_attention_heads * head_dim) * hidden_size
          - gate_proj: hidden_size * intermediate_size
          - up_proj: hidden_size * intermediate_size
          - down_proj: intermediate_size * hidden_size
          - input_layernorm + post_attention_layernorm: 2 * hidden_size
        - Final RMSNorm: hidden_size
        - LM Head: 0 if tie_word_embeddings else vocab_size * hidden_size
        """
        embed_params = self.vocab_size * self.hidden_size
        q_params = self.hidden_size * (self.num_attention_heads * self.head_dim)
        kv_params = 2 * self.hidden_size * (self.num_key_value_heads * self.head_dim)
        o_params = (self.num_attention_heads * self.head_dim) * self.hidden_size
        mlp_params = 3 * self.hidden_size * self.intermediate_size
        norm_params = 2 * self.hidden_size
        layer_params = q_params + kv_params + o_params + mlp_params + norm_params
        total = embed_params + (self.num_hidden_layers * layer_params) + self.hidden_size
        if not self.tie_word_embeddings:
            total += self.vocab_size * self.hidden_size
        return total

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["parameter_count"] = self.estimate_parameter_count()
        return d


PRESET_CONFIGS: Dict[str, SKLLMConfig] = {
    "sk-llm-mini": SKLLMConfig(
        name="SK AI Mini",
        variant_id="sk-llm-mini",
        vocab_size=4096,
        hidden_size=128,
        intermediate_size=384,
        num_hidden_layers=4,
        num_attention_heads=4,
        num_key_value_heads=2,
        max_position_embeddings=4096,
        rms_norm_eps=1e-6,
        rope_theta=10000.0,
        tie_word_embeddings=True,
        use_cache=True,
        gradient_checkpointing=False,
        dtype="fp32",
    ),
    "sk-llm-small": SKLLMConfig(
        name="SK AI Small",
        variant_id="sk-llm-small",
        vocab_size=64000,
        hidden_size=2048,
        intermediate_size=5632,
        num_hidden_layers=24,
        num_attention_heads=16,
        num_key_value_heads=4,
        max_position_embeddings=8192,
        rms_norm_eps=1e-6,
        rope_theta=10000.0,
        tie_word_embeddings=True,
        use_cache=True,
        gradient_checkpointing=True,
        dtype="bf16",
    ),
    "sk-llm-medium": SKLLMConfig(
        name="SK AI Medium",
        variant_id="sk-llm-medium",
        vocab_size=64000,
        hidden_size=4096,
        intermediate_size=11008,
        num_hidden_layers=32,
        num_attention_heads=32,
        num_key_value_heads=8,
        max_position_embeddings=32768,
        rms_norm_eps=1e-5,
        rope_theta=500000.0,
        tie_word_embeddings=False,
        use_cache=True,
        gradient_checkpointing=True,
        dtype="bf16",
    ),
    "sk-llm-large": SKLLMConfig(
        name="SK AI Large",
        variant_id="sk-llm-large",
        vocab_size=128256,
        hidden_size=8192,
        intermediate_size=28672,
        num_hidden_layers=64,
        num_attention_heads=64,
        num_key_value_heads=8,
        max_position_embeddings=131072,
        rms_norm_eps=1e-5,
        rope_theta=500000.0,
        tie_word_embeddings=False,
        use_cache=True,
        gradient_checkpointing=True,
        dtype="bf16",
    ),
}


def get_model_config(variant: str = "sk-llm-mini") -> SKLLMConfig:
    key = variant.lower().strip()
    aliases = {
        "mini": "sk-llm-mini",
        "small": "sk-llm-small",
        "medium": "sk-llm-medium",
        "large": "sk-llm-large",
    }
    key = aliases.get(key, key)
    if key not in PRESET_CONFIGS:
        raise ValueError(f"Unknown SK-LLM model variant '{variant}'. Available: {list(PRESET_CONFIGS.keys())}")
    return PRESET_CONFIGS[key]
