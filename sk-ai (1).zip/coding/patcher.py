"""
SKCodePatcher: Generates unified diffs and applies safe, verifiable patches to files.
"""

import difflib
import os
from typing import Dict, Any


class SKCodePatcher:
    @staticmethod
    def create_unified_diff(original: str, modified: str, filename: str = "file") -> str:
        diff = difflib.unified_diff(
            original.splitlines(keepends=True),
            modified.splitlines(keepends=True),
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
        )
        return "".join(diff)

    @classmethod
    def apply_replacement(
        cls,
        filepath: str,
        target_snippet: str,
        replacement_snippet: str,
        user_confirmed: bool = False,
    ) -> Dict[str, Any]:
        if not user_confirmed:
            return {
                "applied": False,
                "requires_confirmation": True,
                "message": "File modification requires explicit confirmation (`user_confirmed=True`).",
            }
        if not os.path.exists(filepath):
            return {"applied": False, "error": f"File not found: {filepath}"}
        with open(filepath, "r", encoding="utf-8") as f:
            orig = f.read()
        if target_snippet not in orig:
            return {"applied": False, "error": "Target snippet not found in file."}
        updated = orig.replace(target_snippet, replacement_snippet, 1)
        diff = cls.create_unified_diff(orig, updated, os.path.basename(filepath))
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(updated)
        return {"applied": True, "filepath": filepath, "diff": diff}
