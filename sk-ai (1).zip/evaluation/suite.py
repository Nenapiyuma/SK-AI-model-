"""
SKEvaluationSuite: Runs real empirical checks on all SK AI subsystems and records actual
measured execution times, token round-trip accuracy, AST validity, and file generation metrics
to `benchmarks/results/latest_results.json`. Never invents fake benchmark scores.
"""

import os
import json
import time
from typing import Dict, Any
from tokenizer.sk_tokenizer import SKTokenizer
from inference.engine import SKInferenceEngine
from coding.code_model import SKCodeModel
from image.pipeline import SKImagePipeline
from music.music_model import SKMusicModel
from video.video_model import SKVideoModel
from vision.vision_model import SKVisionModel


class SKEvaluationSuite:
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = os.path.abspath(workspace_root)
        self.results_dir = os.path.join(self.workspace_root, "benchmarks", "results")
        os.makedirs(self.results_dir, exist_ok=True)

    def run_all_evaluations(self) -> Dict[str, Any]:
        t_start = time.perf_counter()
        tok = SKTokenizer()
        engine = SKInferenceEngine()
        coder = SKCodeModel()
        img_pipe = SKImagePipeline()
        music_mod = SKMusicModel()
        vid_mod = SKVideoModel()
        vis_mod = SKVisionModel()

        # 1. Sinhala Tokenization & Generation Verification
        si_sample = "ආයුබෝවන්! ක්වොන්ටම් පරිගණනය පැහැදිලි කරන්න."
        si_ids = tok.encode(si_sample)
        si_decoded = tok.decode(si_ids)
        si_gen = engine.generate(si_sample, max_new_tokens=8)

        # 2. English Reasoning & Instruction Following
        en_sample = "Explain quantum computing in structured JSON."
        en_gen = engine.generate(en_sample, max_new_tokens=8, structured_json=True)
        json_valid = False
        try:
            json.loads(en_gen["text"])
            json_valid = True
        except Exception:
            pass

        # 3. Coding AST Evaluation
        code_res = coder.generate_code("Write a Python task processor", language="Python")

        # 4. Image + Vision Evaluation
        img_out_path = os.path.join(self.results_dir, "eval_sample.png")
        img_res = img_pipe.run("Calm ocean horizon in Sri Lanka", width=64, height=64, steps=4, output_path=img_out_path)
        vis_res = vis_mod.analyze_image(img_out_path, "Check image dimensions")

        # 5. Music Evaluation
        mus_prefix = os.path.join(self.results_dir, "eval_song")
        mus_res = music_mod.generate_music("Create a happy Sinhala pop song", duration_sec=1.5, output_prefix=mus_prefix)

        # 6. Video Evaluation
        vid_dir = os.path.join(self.results_dir, "eval_video")
        vid_res = vid_mod.generate_video("Sunrise over mountains", duration_sec=1.0, fps=2, width=64, height=48, output_dir=vid_dir)

        results = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "note": "Actual measured runtime evaluation on local SK AI Mini & procedural subsystems (no fabricated scores).",
            "total_eval_duration_ms": round((time.perf_counter() - t_start) * 1000.0, 2),
            "suites": {
                "sinhala": {
                    "roundtrip_exact_match": si_decoded == si_sample,
                    "script_detected": tok.detect_script(si_sample),
                    "inference_latency_ms": si_gen["trace"]["latency_ms"],
                },
                "english_and_instruction_following": {
                    "structured_json_valid": json_valid,
                    "kv_cache_tokens": en_gen["trace"]["kv_cache_seq_len"],
                    "inference_latency_ms": en_gen["trace"]["latency_ms"],
                },
                "coding": {
                    "language": code_res["language"],
                    "ast_syntax_valid": code_res["syntax_valid"],
                },
                "image_and_vision": {
                    "png_generated": os.path.exists(img_out_path),
                    "png_bytes": img_res["file_size_bytes"],
                    "vision_parsed_dimensions": f"{vis_res['image_metadata']['width']}x{vis_res['image_metadata']['height']}",
                },
                "music": {
                    "midi_generated": os.path.exists(mus_res["midi_path"]),
                    "wav_generated": os.path.exists(mus_res["wav_path"]),
                    "tempo_bpm": mus_res["tempo_bpm"],
                },
                "video": {
                    "frames_generated": vid_res["frame_count"],
                    "vram_warning_emitted": len(vid_res["hardware_check"]["warnings"]) > 0,
                },
            },
        }

        out_file = os.path.join(self.results_dir, "latest_results.json")
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        return results
