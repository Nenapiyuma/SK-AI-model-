"""
SK AI Multimodal Model Router Package.
"""

from .model_router import SKModelRouter

__all__ = ["SKModelRouter"]
