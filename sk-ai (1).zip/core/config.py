"""
SKAIConfig: Manages system configuration, `offline_mode=true` privacy enforcement,
and workspace security settings.
"""

import os
import json
from typing import Dict, Any


class SKAIConfig:
    def __init__(self, config_path: str = "configs/system_config.json", offline_mode: bool = True):
        self.config_path = config_path
        self.offline_mode = offline_mode
        self.data: Dict[str, Any] = {
            "system_name": "SK AI",
            "version": "1.0.0",
            "offline_mode": offline_mode,
            "allow_external_providers": False,
            "telemetry_enabled": False,
            "require_confirmation_for_destructive_tools": True,
            "default_llm_variant": "sk-llm-mini",
        }
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    self.data.update(loaded)
                    self.offline_mode = bool(self.data.get("offline_mode", True))
            except Exception:
                pass

    def set_offline_mode(self, enabled: bool) -> Dict[str, Any]:
        self.offline_mode = enabled
        self.data["offline_mode"] = enabled
        if enabled:
            self.data["allow_external_providers"] = False
            self.data["telemetry_enabled"] = False
        return self.data
