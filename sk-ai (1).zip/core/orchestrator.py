"""
SKAIOrchestrator: End-to-End Multimodal Pipeline Controller.
Manages:
USER -> INTENT -> MODEL ROUTING -> TOOLS -> MODEL EXECUTION -> VALIDATION -> FINAL RESPONSE
"""

from typing import Dict, Any, Optional
from .config import SKAIConfig
from .session import SKAISession
from .router import CoreRouter
from agents.orchestrator import AgentOrchestrator
from inference.engine import SKInferenceEngine
from coding.code_agent import SKCodeAgent
from vision.vision_model import SKVisionModel
from image.pipeline import SKImagePipeline
from music.music_model import SKMusicModel
from video.video_model import SKVideoModel
from audio.audio_model import SKAudioModel
from speech.speech_model import SKSpeechModel
from documents.document_ai import SKDocumentAI
from memory.memory_manager import SKMemoryManager
from android.generator import SKAndroidGenerator
from windows.generator import SKWindowsGenerator
from tools import get_tool_registry


class SKAIOrchestrator:
    def __init__(self, workspace_root: str = ".", offline_mode: bool = True):
        self.config = SKAIConfig(offline_mode=offline_mode)
        self.session = SKAISession(workspace_root=workspace_root)
        self.router = CoreRouter()
        self.agent = AgentOrchestrator()
        self.llm_engine = SKInferenceEngine(variant="sk-llm-mini")
        self.code_agent = SKCodeAgent()
        self.vision_model = SKVisionModel()
        self.image_pipeline = SKImagePipeline()
        self.music_model = SKMusicModel()
        self.video_model = SKVideoModel()
        self.audio_model = SKAudioModel()
        self.speech_model = SKSpeechModel()
        self.document_ai = SKDocumentAI()
        self.memory = SKMemoryManager()
        self.android_gen = SKAndroidGenerator()
        self.windows_gen = SKWindowsGenerator()
        self.tools = get_tool_registry(workspace_root=workspace_root, offline_mode=offline_mode)

    def execute_request(
        self,
        prompt: str,
        image_path: Optional[str] = None,
        audio_path: Optional[str] = None,
        document_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        routed = self.router.route(
            prompt=prompt,
            has_image_input=bool(image_path),
            has_audio_input=bool(audio_path),
            has_document_input=bool(document_path),
        )
        intent = routed["intent"]

        def run_pipeline() -> Dict[str, Any]:
            if intent == "android_development":
                proj = self.android_gen.create_android_project(prompt=prompt)
                return {
                    "text": f"Generated complete Android Studio project '{proj['project_name']}' ({len(proj['files_created'])} files) with Dual-Mode Local/LAN Compose UI.",
                    "payload": proj,
                    "status": "completed",
                }
            if intent == "windows_development":
                proj = self.windows_gen.create_windows_project(prompt=prompt)
                return {
                    "text": f"Generated Windows desktop project '{proj['project_name']}' using stack '{proj['stack']}'. {proj['build_environment_status']}",
                    "payload": proj,
                    "status": "completed",
                }
            if intent == "music_generation":
                mus = self.music_model.generate_music(prompt=prompt)
                if mus.get("blocked_by_copyright_policy"):
                    return {"text": mus["error"], "payload": mus, "error": mus["error"]}
                return {
                    "text": f"Composed '{mus['style']}' at {mus['tempo_bpm']} BPM in {mus['scale']} and exported MIDI + polyphonic WAV + 4 stems.",
                    "payload": mus,
                    "status": "completed",
                }
            if intent == "image_generation":
                img = self.image_pipeline.run(prompt=prompt)
                return {
                    "text": f"Generated {img['width']}x{img['height']} PNG image via local iterative sampler (seed={img['seed']}).",
                    "payload": img,
                    "status": "completed",
                }
            if intent == "video_generation":
                vid = self.video_model.generate_video(prompt=prompt)
                warn_txt = " | ".join(vid["hardware_check"]["warnings"])
                return {
                    "text": f"Generated {vid['frame_count']} temporal frames ({vid['resolution']} @ {vid['fps']} FPS). Hardware Note: {warn_txt}",
                    "payload": vid,
                    "status": "completed",
                }
            if intent == "image_understanding" and image_path:
                vis = self.vision_model.analyze_image(image_path, question=prompt)
                return {"text": vis.get("analysis", "Image analyzed."), "payload": vis, "status": "completed"}
            if intent == "audio_speech":
                if audio_path:
                    tr = self.speech_model.transcribe_audio(audio_path)
                    return {"text": tr.get("transcription", ""), "payload": tr, "status": "completed"}
                tts = self.speech_model.synthesize_speech(prompt)
                return {
                    "text": f"Synthesized local speech WAV ({tts['duration_sec']}s, {tts['sample_rate']} Hz).",
                    "payload": tts,
                    "status": "completed",
                }
            if intent == "document_understanding" and document_path:
                qa = self.document_ai.answer_question(document_path, prompt)
                return {"text": qa.get("best_passage", ""), "payload": qa, "status": "completed"}
            if intent == "coding":
                code_res = self.code_agent.handle_coding_task(prompt=prompt)
                return {
                    "text": f"Generated {code_res['language']} implementation:\n\n```{code_res['language'].lower()}\n{code_res['code']}```",
                    "code": code_res["code"],
                    "payload": code_res,
                    "status": "completed",
                }

            # Default: Text & Reasoning with optional RAG context
            ctx_records = self.memory.query_memory(prompt, top_k=2)
            ctx_strings = [r["text"] for r in ctx_records if r.get("score", 0) > 0.1]
            gen = self.llm_engine.generate(prompt=prompt, context_docs=ctx_strings)
            return {"text": gen["text"], "payload": gen, "status": "completed"}

        orchestrated = self.agent.run_agentic_loop(goal=prompt, routed_info=routed, handler_fn=run_pipeline)
        self.session.add_message("user", prompt)
        self.session.add_message("assistant", orchestrated["answer"], {"routed": routed})

        return {
            "prompt": prompt,
            "routing": routed,
            "answer": orchestrated["answer"],
            "verified": orchestrated["verified"],
            "data": orchestrated["result"].get("payload", orchestrated["result"]),
            "offline_mode": self.config.offline_mode,
        }
