import React, { useState, useEffect } from 'react';
import { Play, Pause, Music, Image as ImageIcon, Film, Volume2, AlertTriangle } from 'lucide-react';

interface MultimodalStudioProps {
  darkMode: boolean;
}

export const MultimodalStudio: React.FC<MultimodalStudioProps> = ({ darkMode }) => {
  const [activeModality, setActiveModality] = useState<'music' | 'image' | 'video' | 'speech'>('music');
  const [loading, setLoading] = useState(false);

  // Music state
  const [musicPrompt, setMusicPrompt] = useState('Create a happy Sinhala pop song');
  const [musicDuration, setMusicDuration] = useState(3.5);
  const [transformStyle, setTransformStyle] = useState('Cinematic Orchestral');
  const [tempoMultiplier, setTempoMultiplier] = useState(1.0);
  const [musicResult, setMusicResult] = useState<Record<string, any> | null>(null);

  // Image state
  const [imagePrompt, setImagePrompt] = useState('Calm ocean horizon in Sri Lanka at golden hour');
  const [negativePrompt, setNegativePrompt] = useState('blurry, low contrast, artifacts');
  const [imgSteps, setImgSteps] = useState(12);
  const [imgGuidance, setImgGuidance] = useState(7.5);
  const [imgSeed, setImgSeed] = useState(42);
  const [imageResult, setImageResult] = useState<Record<string, any> | null>(null);

  // Video state
  const [videoPrompt, setVideoPrompt] = useState('Sunrise over misty central highlands');
  const [videoFps, setVideoFps] = useState(4);
  const [videoDuration, setVideoDuration] = useState(1.5);
  const [videoSeed, setVideoSeed] = useState(42);
  const [videoResult, setVideoResult] = useState<Record<string, any> | null>(null);
  const [activeFrameIdx, setActiveFrameIdx] = useState(0);
  const [isPlayingVideo, setIsPlayingVideo] = useState(true);

  // Speech state
  const [speechText, setSpeechText] = useState('Ayubowan! Welcome to SK AI local multimodal synthesis.');
  const [speechResult, setSpeechResult] = useState<Record<string, any> | null>(null);

  useEffect(() => {
    if (!videoResult?.frame_data_urls?.length || !isPlayingVideo) return;
    const interval = setInterval(() => {
      setActiveFrameIdx((prev) => (prev + 1) % videoResult.frame_data_urls.length);
    }, Math.max(150, Math.round(1000 / (videoResult.fps || 4))));
    return () => clearInterval(interval);
  }, [videoResult, isPlayingVideo]);

  const runMusic = async (overridePrompt?: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: overridePrompt ?? musicPrompt,
          duration_sec: musicDuration,
          transform_style: transformStyle || undefined,
          tempo_multiplier: tempoMultiplier,
        }),
      });
      const data = await res.json();
      if (data.ok) setMusicResult(data.result);
    } finally {
      setLoading(false);
    }
  };

  const runImage = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imagePrompt,
          negative_prompt: negativePrompt,
          width: 192,
          height: 192,
          steps: imgSteps,
          guidance_scale: imgGuidance,
          seed: imgSeed,
        }),
      });
      const data = await res.json();
      if (data.ok) setImageResult(data.result);
    } finally {
      setLoading(false);
    }
  };

  const runVideo = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: videoPrompt,
          fps: videoFps,
          duration_sec: videoDuration,
          seed: videoSeed,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setVideoResult(data.result);
        setActiveFrameIdx(0);
      }
    } finally {
      setLoading(false);
    }
  };

  const runSpeech = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/skai/speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: speechText }),
      });
      const data = await res.json();
      if (data.ok) setSpeechResult(data.result);
    } finally {
      setLoading(false);
    }
  };

  const surfaceCls = darkMode
    ? 'bg-slate-900 border-slate-800 text-slate-100'
    : 'bg-white border-slate-200 text-slate-900';
  const inputCls = darkMode
    ? 'bg-slate-950 border-slate-800 text-slate-100 focus:border-emerald-500'
    : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-slate-900';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">02. Local Multimodal Synthesis Studio</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Execute SK-MUSIC, SK-IMAGE, SK-VIDEO, and SK-SPEECH pipelines locally with deterministic seeds and hardware checks.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          {[
            { id: 'music', label: 'SK-MUSIC (WAV/MIDI/Stems)', icon: Music },
            { id: 'image', label: 'SK-IMAGE (Diffusion)', icon: ImageIcon },
            { id: 'video', label: 'SK-VIDEO (Temporal)', icon: Film },
            { id: 'speech', label: 'SK-SPEECH (Formant TTS)', icon: Volume2 },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeModality === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveModality(tab.id as any)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {activeModality === 'music' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-5 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Music Composition & Arrangement Controls</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Musical Prompt (Sinhala or English)</label>
              <input
                type="text"
                value={musicPrompt}
                onChange={(e) => setMusicPrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border outline-none ${inputCls}`}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Duration (sec)</label>
                <input
                  type="number"
                  step="0.5"
                  min="1"
                  max="10"
                  value={musicDuration}
                  onChange={(e) => setMusicDuration(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Tempo Multiplier</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.5"
                  max="2.0"
                  value={tempoMultiplier}
                  onChange={(e) => setTempoMultiplier(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">
                Song → Arrangement Transformation Style
              </label>
              <select
                value={transformStyle}
                onChange={(e) => setTransformStyle(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              >
                <option value="">Original Prompt Style</option>
                <option value="Cinematic Orchestral">Cinematic Orchestral Arrangement</option>
                <option value="Sinhala Baila Acoustic">Sinhala Baila Acoustic Arrangement</option>
                <option value="Ambient Synthwave">Ambient Synthwave Arrangement</option>
              </select>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              <button
                onClick={() => runMusic()}
                disabled={loading}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors whitespace-nowrap"
              >
                {loading ? 'Synthesizing WAV & MIDI...' : 'Compose & Synthesize Music'}
              </button>
              <button
                onClick={() => {
                  setMusicPrompt('Please clone voice of living artist');
                  runMusic('Please clone voice of living artist');
                }}
                disabled={loading}
                className="px-3 py-2 text-xs font-medium border border-amber-500/40 text-amber-600 dark:text-amber-400 rounded-lg hover:bg-amber-500/10 transition-colors whitespace-nowrap"
              >
                Test Anti-Voice-Cloning Guardrail
              </button>
            </div>
          </div>

          <div className={`lg:col-span-7 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Synthesized Output, Stems & Rights Documentation</h3>
            {!musicResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Click &ldquo;Compose &amp; Synthesize Music&rdquo; to generate a polyphonic WAV mixdown, standard MIDI file, and 4 separated instrument stems.
              </div>
            ) : musicResult.blocked_by_copyright_policy ? (
              <div className="p-4 rounded-lg border border-red-500/40 bg-red-500/10 space-y-2">
                <div className="flex items-center gap-2 text-red-500 font-semibold text-sm">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Blocked by SK-MUSIC Copyright &amp; Anti-Cloning Policy</span>
                </div>
                <p className="text-xs leading-relaxed">{musicResult.error}</p>
                <p className="text-xs text-slate-400">{musicResult.copyright_notice}</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                  <span>Style: {musicResult.style}</span>
                  <span>·</span>
                  <span>Tempo: {musicResult.tempo_bpm} BPM</span>
                  <span>·</span>
                  <span>Scale: {musicResult.scale}</span>
                  <span>·</span>
                  <span>Chords: {(musicResult.chord_progression || []).join(' – ')}</span>
                </div>

                {musicResult.audio_data_url && (
                  <div className="pt-2">
                    <p className="text-xs font-medium mb-1.5">Playable Polyphonic 16-Bit PCM WAV Output:</p>
                    <audio controls src={musicResult.audio_data_url} className="w-full" />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-xs font-mono tabular-nums">
                  <div>
                    <p className="font-semibold text-slate-400 mb-1">Exported Files on Disk</p>
                    <p>WAV: {musicResult.wav_path} ({musicResult.wav_size_bytes?.toLocaleString()} B)</p>
                    <p>MIDI: {musicResult.midi_path} ({musicResult.midi_size_bytes?.toLocaleString()} B)</p>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-400 mb-1">Separated Instrument Stems</p>
                    {musicResult.stems &&
                      Object.entries(musicResult.stems).map(([stemName, stemPath]) => (
                        <p key={stemName}>
                          {stemName}: {String(stemPath)}
                        </p>
                      ))}
                  </div>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-400 border-t border-slate-200 dark:border-slate-800 pt-3">
                  {musicResult.copyright_notice}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeModality === 'image' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-5 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">SK-IMAGE Conditioning &amp; Sampler Parameters</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Positive Prompt</label>
              <input
                type="text"
                value={imagePrompt}
                onChange={(e) => setImagePrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Negative Prompt</label>
              <input
                type="text"
                value={negativePrompt}
                onChange={(e) => setNegativePrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Steps</label>
                <input
                  type="number"
                  value={imgSteps}
                  onChange={(e) => setImgSteps(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Guidance</label>
                <input
                  type="number"
                  step="0.5"
                  value={imgGuidance}
                  onChange={(e) => setImgGuidance(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Seed</label>
                <input
                  type="number"
                  value={imgSeed}
                  onChange={(e) => setImgSeed(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
            </div>
            <button
              onClick={runImage}
              disabled={loading}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
            >
              {loading ? 'Sampling Local PNG...' : 'Run Iterative Sampler'}
            </button>
          </div>

          <div className={`lg:col-span-7 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Rendered PNG Buffer &amp; Weight Status</h3>
            {!imageResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Click &ldquo;Run Iterative Sampler&rdquo; to generate a seeded RFC-2083 PNG image locally.
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row gap-6 items-start">
                <img
                  src={imageResult.data_url}
                  alt={imageResult.prompt}
                  referrerPolicy="no-referrer"
                  className="w-48 h-48 rounded-lg border border-slate-700 object-cover shrink-0"
                />
                <div className="space-y-2 text-xs font-mono tabular-nums">
                  <p>Resolution: {imageResult.width}x{imageResult.height} px</p>
                  <p>File Size: {imageResult.file_size_bytes?.toLocaleString()} bytes</p>
                  <p>Seed: {imageResult.seed} · Steps: {imageResult.steps} · Guidance: {imageResult.guidance_scale}</p>
                  <p>Saved Path: {imageResult.output_path}</p>
                  <p className="text-slate-400 pt-2">
                    Local Engine: {imageResult.model_status?.local_procedural_engine}
                  </p>
                  <p className="text-amber-500">
                    SDXL Checkpoint: {imageResult.model_status?.third_party_sdxl_weights}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeModality === 'video' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-5 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">SK-VIDEO Temporal Frame Synthesizer</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Video Prompt</label>
              <input
                type="text"
                value={videoPrompt}
                onChange={(e) => setVideoPrompt(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">FPS</label>
                <input
                  type="number"
                  min="2"
                  max="8"
                  value={videoFps}
                  onChange={(e) => setVideoFps(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Duration (s)</label>
                <input
                  type="number"
                  step="0.5"
                  min="1"
                  max="3"
                  value={videoDuration}
                  onChange={(e) => setVideoDuration(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Seed</label>
                <input
                  type="number"
                  value={videoSeed}
                  onChange={(e) => setVideoSeed(Number(e.target.value))}
                  className={`w-full px-3 py-2 text-sm rounded-lg border font-mono tabular-nums ${inputCls}`}
                />
              </div>
            </div>
            <button
              onClick={runVideo}
              disabled={loading}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
            >
              {loading ? 'Rendering Temporal Frames...' : 'Generate Video Sequence'}
            </button>
          </div>

          <div className={`lg:col-span-7 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Temporal Playback &amp; Pre-Flight VRAM Check</h3>
            {!videoResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Click &ldquo;Generate Video Sequence&rdquo; to run hardware VRAM compatibility checks and synthesize temporally coherent frames.
              </div>
            ) : (
              <div className="space-y-4">
                {videoResult.hardware_check?.warnings?.length > 0 && (
                  <div className="p-3 rounded-lg border border-amber-500/40 bg-amber-500/10 text-xs space-y-1">
                    <div className="font-semibold text-amber-500 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Hardware VRAM Pre-Flight Warning (hardware/compatibility.py)</span>
                    </div>
                    {videoResult.hardware_check.warnings.map((w: string, idx: number) => (
                      <p key={idx} className="text-slate-600 dark:text-slate-300">{w}</p>
                    ))}
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-6 items-start">
                  <div className="space-y-2">
                    <img
                      src={videoResult.frame_data_urls?.[activeFrameIdx]}
                      alt={`Frame ${activeFrameIdx}`}
                      referrerPolicy="no-referrer"
                      className="w-56 h-42 rounded-lg border border-slate-700 object-cover"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setIsPlayingVideo((p) => !p)}
                        className="px-2.5 py-1 text-xs font-medium rounded border border-slate-700 flex items-center gap-1"
                      >
                        {isPlayingVideo ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                        <span>{isPlayingVideo ? 'Pause' : 'Play'}</span>
                      </button>
                      <span className="text-xs font-mono tabular-nums text-slate-400">
                        Frame {activeFrameIdx + 1} / {videoResult.frame_count} @ {videoResult.fps} FPS
                      </span>
                    </div>
                  </div>
                  <div className="text-xs font-mono tabular-nums space-y-1.5">
                    <p>Mode: {videoResult.mode}</p>
                    <p>Resolution: {videoResult.resolution}</p>
                    <p>Total Sequence Bytes: {videoResult.total_size_bytes?.toLocaleString()} B</p>
                    <p>Manifest: {videoResult.manifest_path}</p>
                    <p className="text-amber-500 pt-1">{videoResult.external_dit_weights_status}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeModality === 'speech' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className={`lg:col-span-5 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">SK-SPEECH Formant Synthesizer</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Speech Text</label>
              <textarea
                rows={3}
                value={speechText}
                onChange={(e) => setSpeechText(e.target.value)}
                className={`w-full px-3 py-2 text-sm rounded-lg border ${inputCls}`}
              />
            </div>
            <button
              onClick={runSpeech}
              disabled={loading}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
            >
              {loading ? 'Synthesizing Formant WAV...' : 'Synthesize Speech to WAV'}
            </button>
          </div>
          <div className={`lg:col-span-7 p-5 rounded-xl border ${surfaceCls} space-y-4`}>
            <h3 className="text-base font-semibold">Audio Output &amp; Acoustic Telemetry</h3>
            {!speechResult ? (
              <div className="py-12 text-center text-sm text-slate-500">
                Click &ldquo;Synthesize Speech to WAV&rdquo; to generate playable formant speech audio locally.
              </div>
            ) : (
              <div className="space-y-3">
                <audio controls src={speechResult.data_url} className="w-full" />
                <div className="text-xs font-mono tabular-nums text-slate-400 space-y-1">
                  <p>File: {speechResult.output_path} ({speechResult.file_size_bytes?.toLocaleString()} bytes)</p>
                  <p>Sample Rate: {speechResult.sample_rate} Hz · Duration: {speechResult.duration_sec}s</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
