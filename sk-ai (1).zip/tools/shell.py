"""
ShellTool: Permission-Gated Shell Execution Tool.
Blocks destructive commands (`rm -rf`, `mkfs`, `dd`, `shutdown`, etc.) and requires
explicit `user_confirmed=True` before executing non-read-only commands.
"""

import subprocess
import shlex
from typing import Dict, Any


DESTRUCTIVE_PATTERNS = ["rm -rf", "mkfs", "dd if=", "shutdown", "reboot", "> /dev/", ":(){ :|:& };:"]
SAFE_READONLY_PREFIXES = ["ls", "pwd", "uname", "python3 --version", "git status", "git log"]


class ShellTool:
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = workspace_root

    def run(self, command: str, user_confirmed: bool = False) -> Dict[str, Any]:
        cmd_clean = command.strip()
        lower = cmd_clean.lower()

        for pat in DESTRUCTIVE_PATTERNS:
            if pat in lower:
                return {
                    "executed": False,
                    "blocked": True,
                    "error": f"Security Policy Violation: Destructive command pattern '{pat}' is permanently blocked.",
                }

        is_readonly = any(lower.startswith(pref) for pref in SAFE_READONLY_PREFIXES)
        if not is_readonly and not user_confirmed:
            return {
                "executed": False,
                "requires_confirmation": True,
                "error": "Shell command requires explicit user confirmation (`user_confirmed=True`).",
            }

        try:
            args = shlex.split(cmd_clean)
            proc = subprocess.run(
                args,
                cwd=self.workspace_root,
                capture_output=True,
                text=True,
                timeout=10,
            )
            return {
                "executed": True,
                "returncode": proc.returncode,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
            }
        except Exception as e:
            return {"executed": False, "error": str(e)}
