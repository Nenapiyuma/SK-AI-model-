"""
SK AI Windows EXE & Desktop Application Development Subsystem (`windows/`).
Supports generating Windows .EXE / portable desktop projects across Python (PyInstaller),
Electron, Tauri, C# (.NET), and C++.
Never claims an .EXE binary was built if the host OS lacks a Windows compiler toolchain.
"""

from .generator import SKWindowsGenerator

__all__ = ["SKWindowsGenerator"]
