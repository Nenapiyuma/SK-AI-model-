"""
SK AI Dataset Management Subsystem (`datasets/`).
Provides dataset validation, SHA-256 deduplication, Sinhala/English language identification,
quality filtering, tokenization, sharding, metadata generation, and license compliance checks.
"""

from .manager import SKDatasetManager

__all__ = ["SKDatasetManager"]
