"""
SKMusicComposer: Generates original melodies, chord progressions, rhythms, and instrumentation
for prompts such as "Create a happy Sinhala pop song" or "Cinematic arrangement".
"""

import hashlib
from typing import Dict, Any, List


SCALES = {
    "C_MAJOR": [60, 62, 64, 65, 67, 69, 71, 72],
    "G_MAJOR": [55, 57, 59, 60, 62, 64, 66, 67],
    "A_MINOR": [57, 59, 60, 62, 64, 65, 67, 69],
    "D_MINOR_CINEMATIC": [50, 52, 53, 55, 57, 58, 60, 62],
}


class SKMusicComposer:
    def compose(self, prompt: str, duration_sec: float = 4.0) -> Dict[str, Any]:
        p = prompt.lower()
        h = hashlib.sha256(prompt.encode("utf-8")).digest()

        if "sinhala" in p or "සිංහල" in prompt or "happy" in p or "pop" in p:
            style = "Sinhala Upbeat Pop (6/8 & 4/4 Fusion)"
            scale_name = "C_MAJOR"
            tempo_bpm = 124
            instrumentation = ["Acoustic Lead Guitar", "Warm Synth Pad", "Electric Bass", "Baila/Pop Percussion"]
            chords = [
                {"name": "C", "notes": [48, 52, 55]},
                {"name": "G", "notes": [43, 47, 50]},
                {"name": "Am", "notes": [45, 48, 52]},
                {"name": "F", "notes": [41, 45, 48]},
            ]
        elif "cinematic" in p or "orchestral" in p or "epic" in p:
            style = "Cinematic Orchestral Arrangement"
            scale_name = "D_MINOR_CINEMATIC"
            tempo_bpm = 92
            instrumentation = ["Solo Cello & Violin Ensemble", "French Horns", "Deep Sub Bass", "Timpani"]
            chords = [
                {"name": "Dm", "notes": [38, 41, 45]},
                {"name": "Bb", "notes": [34, 38, 41]},
                {"name": "F", "notes": [41, 45, 48]},
                {"name": "C", "notes": [36, 40, 43]},
            ]
        else:
            style = "Contemporary Melodic Electronic"
            scale_name = "A_MINOR"
            tempo_bpm = 110
            instrumentation = ["Electric Piano", "Poly Synth", "Sub Bass", "Studio Drums"]
            chords = [
                {"name": "Am", "notes": [45, 48, 52]},
                {"name": "F", "notes": [41, 45, 48]},
                {"name": "C", "notes": [48, 52, 55]},
                {"name": "G", "notes": [43, 47, 50]},
            ]

        scale = SCALES[scale_name]
        num_notes = max(8, int((duration_sec * tempo_bpm) / 60.0 * 2))
        melody_notes: List[Dict[str, Any]] = []
        beat_sec = 60.0 / tempo_bpm / 2.0
        for i in range(num_notes):
            pitch = scale[h[i % len(h)] % len(scale)]
            melody_notes.append(
                {
                    "step": i,
                    "midi_note": pitch,
                    "start_sec": round(i * beat_sec, 3),
                    "duration_sec": round(beat_sec * 0.9, 3),
                    "velocity": 95 if i % 2 == 0 else 78,
                }
            )

        return {
            "prompt": prompt,
            "style": style,
            "scale": scale_name,
            "tempo_bpm": tempo_bpm,
            "duration_sec": duration_sec,
            "instrumentation": instrumentation,
            "chord_progression": chords,
            "melody_notes": melody_notes,
        }
