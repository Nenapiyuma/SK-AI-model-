"""
CoreRouter: Bridges `core/` with `router/model_router.py`.
"""

from router.model_router import SKModelRouter


class CoreRouter(SKModelRouter):
    pass
