export interface StorageRow {
  component: string;
  subsystem: string;
  origin: string;
  size_bytes: number;
  size_formatted: string;
  parameters: number;
  quantization: string;
  status: string;
  license: string;
  sha256: string | null;
}

export interface StorageReport {
  rows: StorageRow[];
  total_installed_bytes: number;
  total_installed_formatted: string;
  total_available_library_bytes: number;
  total_available_library_formatted: string;
  architecture_max_budget: string;
}

export interface SmokeCheck {
  step: number;
  component: string;
  status: string;
  detail: string;
}

export interface SmokeReport {
  all_core_subsystems_passed: boolean;
  core_checks: SmokeCheck[];
  optional_models: { model: string; status: string }[];
}

export interface QuantizationMetric {
  format: string;
  num_parameters: number;
  original_size_bytes: number;
  quantized_size_bytes: number;
  compression_ratio: number;
  estimated_ram_mb: number;
  estimated_vram_mb: number;
  quantization_time_ms: number;
  measured_mse: number;
  measured_snr_db: number;
}

export interface HardwareStatus {
  cpu: {
    model_name: string;
    architecture: string;
    logical_cores: number;
    os: string;
  };
  memory: {
    total_gb: number;
    available_gb: number;
    used_gb: number;
    percent_used: number;
  };
  gpu: {
    gpu_available: boolean;
    cuda_available: boolean;
    gpu_count: number;
    total_vram_gb: number;
    supported_acceleration: string;
  };
  storage: {
    total_gb: number;
    used_gb: number;
    free_gb: number;
    supports_1tb_library_now: boolean;
  };
}

export interface SystemStatusResponse {
  ok: boolean;
  hardware: HardwareStatus;
  storage: StorageReport;
  smoke: SmokeReport;
  quantization_comparison: QuantizationMetric[];
  offline_mode: boolean;
}
