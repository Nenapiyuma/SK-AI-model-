"""
SKVectorStore: Local Persistent Vector Store with Cosine Similarity Retrieval
and Explicit User Deletion / Privacy Controls.
"""

import os
import json
import uuid
import time
from typing import List, Dict, Any, Optional
from .embeddings import SKEmbeddingModel


class SKVectorStore:
    def __init__(self, store_path: str = "memory/local_vectors.json", dim: int = 64):
        self.store_path = os.path.abspath(store_path)
        self.embedder = SKEmbeddingModel(dim=dim)
        self.records: List[Dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        if os.path.exists(self.store_path):
            try:
                with open(self.store_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        self.records = data
            except Exception:
                self.records = []

    def _save(self) -> None:
        os.makedirs(os.path.dirname(self.store_path), exist_ok=True)
        with open(self.store_path, "w", encoding="utf-8") as f:
            json.dump(self.records, f, ensure_ascii=False, indent=2)

    def add_record(
        self,
        text: str,
        category: str = "document",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        rec = {
            "id": str(uuid.uuid4())[:8],
            "text": text,
            "category": category,
            "metadata": metadata or {},
            "embedding": self.embedder.embed_text(text),
            "timestamp": time.time(),
        }
        self.records.append(rec)
        self._save()
        return rec

    def search(
        self,
        query: str,
        top_k: int = 3,
        category: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        q_emb = self.embedder.embed_text(query)
        scored: List[Dict[str, Any]] = []
        for rec in self.records:
            if category and rec.get("category") != category:
                continue
            sim = self.embedder.cosine_similarity(q_emb, rec.get("embedding", []))
            scored.append(
                {
                    "id": rec["id"],
                    "text": rec["text"],
                    "category": rec["category"],
                    "metadata": rec.get("metadata", {}),
                    "score": round(sim, 4),
                }
            )
        scored.sort(key=lambda r: r["score"], reverse=True)
        return scored[:top_k]

    def delete_record(self, record_id: str) -> bool:
        before = len(self.records)
        self.records = [r for r in self.records if r.get("id") != record_id]
        self._save()
        return len(self.records) < before

    def clear_all(self) -> int:
        count = len(self.records)
        self.records.clear()
        self._save()
        return count
