"""
SKModelRouter: Intelligently routes user prompts and multimodal inputs to the appropriate
SK AI model family subsystem(s) and tool pipelines.
"""

from typing import List, Dict, Any, Optional


class SKModelRouter:
    """
    Determines which specialized SK AI model(s) and tool(s) should handle a request:
    - SK-LLM
    - SK-CODE
    - SK-VISION
    - SK-MUSIC
    - SK-IMAGE
    - SK-VIDEO
    - SK-AUDIO
    - SK-SPEECH
    - retrieval
    - tools
    """

    def route(
        self,
        prompt: str,
        has_image_input: bool = False,
        has_audio_input: bool = False,
        has_video_input: bool = False,
        has_document_input: bool = False,
    ) -> Dict[str, Any]:
        p = prompt.lower().strip()
        models: List[str] = []
        tools: List[str] = []
        intent = "text_reasoning"

        # 1. Android Project Development
        if any(k in p for k in ["android", "apk", "jetpack compose", "kotlin app", "androidmanifest", "gradle"]):
            intent = "android_development"
            models = ["SK-CODE", "SK-LLM"]
            tools = ["android", "filesystem", "build"]

        # 2. Windows EXE / Desktop App Development
        elif any(k in p for k in ["windows exe", ".exe", "desktop app", "pyinstaller", "tauri", "electron", "windows app"]):
            intent = "windows_development"
            models = ["SK-CODE", "SK-LLM"]
            tools = ["build", "filesystem"]

        # 3. Music Generation / Song Transformation
        elif any(k in p for k in ["song", "music", "melody", "chord", "midi", "arrangement", "backing track", "stems", "ගීත", "සංගීත"]):
            intent = "music_generation"
            models = ["SK-MUSIC"]
            tools = ["audio"]

        # 4. Video Generation
        elif any(k in p for k in ["generate video", "create video", "text to video", "image to video", "video of", "animation", "වීඩියෝ"]):
            intent = "video_generation"
            models = ["SK-VIDEO"]
            tools = ["video"]

        # 5. Image Generation
        elif any(k in p for k in ["generate image", "create image", "draw ", "paint ", "text to image", "illustration of", "රූපයක් සාදන්න"]):
            intent = "image_generation"
            models = ["SK-IMAGE"]
            tools = ["image"]

        # 6. Vision / Image Understanding / Screenshot OCR
        elif has_image_input or any(k in p for k in ["analyze image", "screenshot", "ocr", "what is in this image", "inspect image"]):
            intent = "image_understanding"
            models = ["SK-VISION", "SK-LLM"]
            tools = ["image"]

        # 7. Audio / Speech
        elif has_audio_input or any(k in p for k in ["transcribe", "speech to text", "text to speech", "synthesize speech", "voice activity", "audio analysis"]):
            intent = "audio_speech"
            models = ["SK-AUDIO", "SK-SPEECH"]
            tools = ["audio"]

        # 8. Document AI / RAG
        elif has_document_input or any(k in p for k in ["summarize document", "pdf", "docx", "xlsx", "analyze table", "extract from document"]):
            intent = "document_understanding"
            models = ["SK-LLM", "retrieval"]
            tools = ["filesystem"]

        # 9. Coding / Software Engineering
        elif any(
            k in p
            for k in [
                "code", "python", "javascript", "typescript", "rust", "c++", "java",
                "swift", "sql", "refactor", "debug", "function", "class ", "def ", "bug",
                "compile", "test", "කේතය",
            ]
        ):
            intent = "coding"
            models = ["SK-CODE", "SK-LLM"]
            tools = ["python", "filesystem", "git"]

        # 10. Default Text & Reasoning
        else:
            intent = "text_reasoning"
            models = ["SK-LLM"]

        return {
            "intent": intent,
            "models": models,
            "tools": tools,
            "primary_model": models[0] if models else "SK-LLM",
            "is_multimodal_pipeline": len(models) > 1 or len(tools) > 0,
        }
