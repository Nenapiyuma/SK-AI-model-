"""
IterativeDiffusionSampler: Deterministic Seeded Iterative Sampler & Native PNG Encoder.
Executes multi-step iterative refinement from seeded Gaussian/uniform noise toward the
prompt-conditioned field and encodes standard RFC-2083 PNG images using `zlib` and `struct`.
"""

import math
import zlib
import struct
import random
from typing import Dict, Any, List, Tuple


def encode_rgb_to_png_bytes(width: int, height: int, rgb_bytes: bytes) -> bytes:
    """Encodes raw RGB24 bytes (width * height * 3) into a valid standard PNG binary."""
    raw_scanlines = bytearray()
    stride = width * 3
    for y in range(height):
        raw_scanlines.append(0)  # Filter type 0 (None)
        raw_scanlines.extend(rgb_bytes[y * stride : (y + 1) * stride])

    def make_chunk(chunk_type: bytes, data: bytes) -> bytes:
        crc = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    compressed = zlib.compress(bytes(raw_scanlines), level=6)
    return (
        b"\x89PNG\r\n\x1a\n"
        + make_chunk(b"IHDR", ihdr)
        + make_chunk(b"IDAT", compressed)
        + make_chunk(b"IEND", b"")
    )


class IterativeDiffusionSampler:
    def sample_rgb_grid(
        self,
        conditioning: Dict[str, Any],
        width: int = 128,
        height: int = 128,
        steps: int = 12,
        guidance_scale: float = 7.5,
        seed: int = 42,
        init_rgb: bytes | None = None,
        strength: float = 0.75,
    ) -> Tuple[bytes, Dict[str, Any]]:
        rng = random.Random(seed)
        r1, g1, b1 = conditioning["primary_rgb"]
        r2, g2, b2 = conditioning["secondary_rgb"]
        fx = conditioning["freq_x"]
        fy = conditioning["freq_y"]
        cond_vec = conditioning["conditioning_vector"]

        buf = bytearray(width * height * 3)
        # Step 1: Initialize latent field (either from init_rgb for img2img or seeded noise)
        noise_weight = strength if init_rgb else 1.0
        # Iterative denoising schedule alpha_t across `steps`
        alpha_schedule = [1.0 - (s + 1) / max(1, steps) for s in range(steps)]
        final_noise_scale = alpha_schedule[-1] * 18.0 * noise_weight

        idx = 0
        for y in range(height):
            ny = y / max(1, height - 1)
            for x in range(width):
                nx = x / max(1, width - 1)
                # Smooth harmonic field modulated by guidance_scale and prompt conditioning vector
                wave = 0.5 + 0.5 * math.sin(nx * math.pi * fx + cond_vec[0] * 6.28) * math.cos(
                    ny * math.pi * fy + cond_vec[1] * 6.28
                )
                radial = math.sqrt((nx - 0.5) ** 2 + (ny - 0.5) ** 2)
                glow = max(0.0, 1.0 - radial * (1.1 + 0.05 * min(guidance_scale, 15.0)))

                tr = r1 * (1.0 - wave) + r2 * wave + 35.0 * glow
                tg = g1 * (1.0 - wave) + g2 * wave + 30.0 * glow
                tb = b1 * (1.0 - wave) + b2 * wave + 40.0 * glow

                if init_rgb and idx + 2 < len(init_rgb):
                    tr = init_rgb[idx] * (1.0 - strength) + tr * strength
                    tg = init_rgb[idx + 1] * (1.0 - strength) + tg * strength
                    tb = init_rgb[idx + 2] * (1.0 - strength) + tb * strength

                jitter = (rng.random() - 0.5) * final_noise_scale
                buf[idx] = max(0, min(255, int(tr + jitter)))
                buf[idx + 1] = max(0, min(255, int(tg + jitter)))
                buf[idx + 2] = max(0, min(255, int(tb + jitter)))
                idx += 3

        png_bytes = encode_rgb_to_png_bytes(width, height, bytes(buf))
        return png_bytes, {
            "width": width,
            "height": height,
            "steps": steps,
            "guidance_scale": guidance_scale,
            "seed": seed,
        }
