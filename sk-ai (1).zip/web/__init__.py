"""
SK AI Web Interface & Backend JSON Bridge (`web/`).
Connects the React/Vite Web UI and Express `server.ts` directly to the local Python SK AI runtime.
"""

from .api_bridge import handle_bridge_command

__all__ = ["handle_bridge_command"]
