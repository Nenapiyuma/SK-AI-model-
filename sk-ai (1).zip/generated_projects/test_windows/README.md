# SKAIDesktopApp (Windows EXE via Electron Wrapper)

## How to Build `.EXE` on Windows
1. Install Node.js LTS on Windows.
2. Run `npm install`.
3. Run `npm run build:exe` to produce the portable `.exe` in `dist/`.
