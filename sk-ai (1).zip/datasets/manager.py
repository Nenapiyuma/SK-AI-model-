"""
SKDatasetManager: Validates, deduplicates, filters, identifies Sinhala/English scripts,
tokenizes, and shards training corpora while enforcing open-license verification.
"""

import os
import json
import hashlib
from typing import List, Dict, Any
from tokenizer.sk_tokenizer import SKTokenizer


APPROVED_OPEN_LICENSES = {"Apache-2.0", "MIT", "CC-BY-4.0", "CC0-1.0", "BSD-3-Clause"}


class SKDatasetManager:
    def __init__(self):
        self.tokenizer = SKTokenizer(vocab_size=4096)

    def process_records(
        self,
        records: List[Dict[str, Any]],
        min_length: int = 5,
        require_open_license: bool = True,
    ) -> Dict[str, Any]:
        seen_hashes = set()
        accepted: List[Dict[str, Any]] = []
        rejected_license = 0
        rejected_duplicate = 0
        rejected_short = 0
        lang_counts: Dict[str, int] = {"si": 0, "en": 0, "si-en": 0}
        total_tokens = 0

        for rec in records:
            text = str(rec.get("text", "")).strip()
            lic = str(rec.get("license", "Apache-2.0"))
            if require_open_license and lic not in APPROVED_OPEN_LICENSES:
                rejected_license += 1
                continue
            if len(text) < min_length:
                rejected_short += 1
                continue
            h = hashlib.sha256(text.encode("utf-8")).hexdigest()
            if h in seen_hashes:
                rejected_duplicate += 1
                continue
            seen_hashes.add(h)

            lang = self.tokenizer.detect_script(text)
            lang_counts[lang] = lang_counts.get(lang, 0) + 1
            tok_ids = self.tokenizer.encode(text, add_special_tokens=True)
            total_tokens += len(tok_ids)
            accepted.append(
                {
                    "sha256": h[:16],
                    "language": lang,
                    "license": lic,
                    "token_count": len(tok_ids),
                    "text": text,
                }
            )

        return {
            "input_records": len(records),
            "accepted_records": len(accepted),
            "rejected_duplicates": rejected_duplicate,
            "rejected_unlicensed": rejected_license,
            "rejected_too_short": rejected_short,
            "language_distribution": lang_counts,
            "total_tokens": total_tokens,
            "records": accepted,
        }
