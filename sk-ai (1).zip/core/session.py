"""
SKAISession: Tracks local conversation history and active project workspace directory.
"""

import uuid
import time
from typing import List, Dict, Any


class SKAISession:
    def __init__(self, workspace_root: str = "."):
        self.session_id = str(uuid.uuid4())[:12]
        self.created_at = time.time()
        self.workspace_root = workspace_root
        self.messages: List[Dict[str, Any]] = []

    def add_message(self, role: str, content: str, metadata: Dict[str, Any] | None = None) -> None:
        self.messages.append(
            {
                "role": role,
                "content": content,
                "metadata": metadata or {},
                "timestamp": time.time(),
            }
        )

    def clear(self) -> None:
        self.messages.clear()
