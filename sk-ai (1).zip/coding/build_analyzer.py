"""
SKBuildAnalyzer: Diagnoses Python tracebacks, TypeScript/Vite compiler errors,
Android Gradle/Kotlin build logs, and Windows packaging errors.
"""

import re
from typing import Dict, Any, List


class SKBuildAnalyzer:
    @staticmethod
    def analyze_build_log(log_text: str) -> Dict[str, Any]:
        diagnostics: List[Dict[str, str]] = []
        lower = log_text.lower()

        if "unresolved reference" in lower or "e: file:" in lower:
            diagnostics.append(
                {
                    "ecosystem": "Android / Kotlin (Gradle)",
                    "issue": "Kotlin Unresolved Reference or Missing Import",
                    "suggestion": "Verify package imports in MainActivity.kt and ensure Compose BOM dependency is declared in app/build.gradle.kts.",
                }
            )
        if "sdk location not found" in lower or "local.properties" in lower:
            diagnostics.append(
                {
                    "ecosystem": "Android SDK",
                    "issue": "Android SDK path not configured",
                    "suggestion": "Define `sdk.dir=/path/to/Android/Sdk` in `local.properties` or set the `ANDROID_HOME` environment variable.",
                }
            )
        if "ts2307" in lower or "cannot find module" in lower:
            diagnostics.append(
                {
                    "ecosystem": "TypeScript / Vite",
                    "issue": "Missing module or type declaration (TS2307)",
                    "suggestion": "Check the import path casing and ensure the package is installed in package.json.",
                }
            )
        if "syntaxerror" in lower or "indentationerror" in lower:
            diagnostics.append(
                {
                    "ecosystem": "Python",
                    "issue": "Python Syntax / Indentation Error",
                    "suggestion": "Run `SKCodeModel.debug_code()` to pinpoint the exact line and column offset.",
                }
            )

        if not diagnostics:
            diagnostics.append(
                {
                    "ecosystem": "General Build System",
                    "issue": "No critical fatal pattern matched",
                    "suggestion": "Inspect compiler exit code and warning flags.",
                }
            )

        return {
            "error_detected": any(k in lower for k in ["error", "exception", "failed", "unresolved"]),
            "diagnostics": diagnostics,
        }
