"""
SKQuantizer: Real Weight Quantization & Empirical Error Measurement.
Never claims quality retention without measuring actual reconstruction Mean Squared Error (MSE)
and Signal-to-Noise Ratio (SNR in dB).
"""

import math
import time
import struct
from typing import List, Dict, Any
from model.tensor_backend import SKMatrix


class SKQuantizer:
    SUPPORTED_FORMATS = ["FP32", "FP16", "BF16", "INT8", "4-bit"]

    @staticmethod
    def quantize_and_measure(matrix: SKMatrix, fmt: str = "INT8") -> Dict[str, Any]:
        fmt_upper = fmt.upper()
        t0 = time.perf_counter()
        orig = list(matrix.data)
        n = len(orig)
        if n == 0:
            raise ValueError("Cannot quantize empty matrix")

        max_abs = max(abs(x) for x in orig) or 1e-8
        reconstructed: List[float] = [0.0] * n

        if fmt_upper == "FP32":
            bytes_per_param = 4.0
            reconstructed = list(orig)
        elif fmt_upper == "FP16":
            bytes_per_param = 2.0
            # Pack/unpack IEEE 754 binary16
            for i, x in enumerate(orig):
                try:
                    packed = struct.pack("<e", x)
                    reconstructed[i] = struct.unpack("<e", packed)[0]
                except OverflowError:
                    reconstructed[i] = math.copysign(65504.0, x)
        elif fmt_upper == "BF16":
            bytes_per_param = 2.0
            # Truncate lower 16 bits of IEEE 754 float32 mantissa
            for i, x in enumerate(orig):
                b = struct.pack("<f", x)
                bf_bytes = b"\x00\x00" + b[2:4]
                reconstructed[i] = struct.unpack("<f", bf_bytes)[0]
        elif fmt_upper == "INT8":
            bytes_per_param = 1.0
            scale = max_abs / 127.0
            for i, x in enumerate(orig):
                q = max(-127, min(127, int(round(x / scale))))
                reconstructed[i] = q * scale
        elif fmt_upper in ("4-BIT", "INT4", "NF4"):
            bytes_per_param = 0.5
            # Blockwise 4-bit symmetric quantization (-7 .. +7) with block_size=32
            block_size = 32
            for start in range(0, n, block_size):
                end = min(n, start + block_size)
                blk = orig[start:end]
                b_max = max(abs(v) for v in blk) or 1e-8
                b_scale = b_max / 7.0
                for j in range(start, end):
                    q = max(-7, min(7, int(round(orig[j] / b_scale))))
                    reconstructed[j] = q * b_scale
        else:
            raise ValueError(f"Unsupported quantization format '{fmt}'. Supported: {SKQuantizer.SUPPORTED_FORMATS}")

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        mse = sum((orig[i] - reconstructed[i]) ** 2 for i in range(n)) / n
        signal_power = sum(x * x for x in orig) / n
        snr_db = 100.0 if mse <= 1e-15 else round(10.0 * math.log10(max(1e-12, signal_power) / mse), 2)

        orig_bytes = n * 4
        quant_bytes = int(math.ceil(n * bytes_per_param))
        return {
            "format": fmt_upper,
            "num_parameters": n,
            "original_size_bytes": orig_bytes,
            "quantized_size_bytes": quant_bytes,
            "compression_ratio": round(orig_bytes / max(1, quant_bytes), 2),
            "estimated_ram_mb": round((quant_bytes * 1.2) / (1024 * 1024), 4),
            "estimated_vram_mb": round((quant_bytes * 1.15) / (1024 * 1024), 4),
            "quantization_time_ms": round(elapsed_ms, 2),
            "measured_mse": round(mse, 8),
            "measured_snr_db": snr_db,
        }

    @classmethod
    def compare_all_formats(cls, matrix: SKMatrix) -> List[Dict[str, Any]]:
        return [cls.quantize_and_measure(matrix, fmt) for fmt in cls.SUPPORTED_FORMATS]
