"""
PromptConditioner: Converts positive and negative text prompts into deterministic
spatial-spectral conditioning vectors and color palettes for SK-IMAGE.
"""

import hashlib
import math
from typing import Dict, Any, List, Tuple


class PromptConditioner:
    def encode_prompt(self, prompt: str, negative_prompt: str = "") -> Dict[str, Any]:
        h_pos = hashlib.sha256(prompt.encode("utf-8")).digest()
        h_neg = hashlib.sha256(negative_prompt.encode("utf-8")).digest() if negative_prompt else bytes(32)

        cond_vec: List[float] = []
        for i in range(32):
            val = (h_pos[i] - 0.35 * h_neg[i]) / 255.0
            cond_vec.append(round(val, 5))

        p_lower = prompt.lower()
        # Derive harmonic primary/secondary RGB palette from prompt semantics + hash
        if any(w in p_lower for w in ["ocean", "sea", "water", "blue", "sky"]):
            primary = (24, 98, 185)
            secondary = (90, 200, 235)
        elif any(w in p_lower for w in ["forest", "nature", "green", "tree", "sri lanka", "tea"]):
            primary = (28, 120, 74)
            secondary = (165, 220, 120)
        elif any(w in p_lower for w in ["sunset", "fire", "gold", "warm", "cinematic"]):
            primary = (210, 85, 45)
            secondary = (245, 190, 80)
        else:
            primary = (40 + (h_pos[0] % 140), 50 + (h_pos[1] % 140), 80 + (h_pos[2] % 140))
            secondary = (100 + (h_pos[3] % 130), 90 + (h_pos[4] % 130), 120 + (h_pos[5] % 120))

        return {
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "conditioning_vector": cond_vec,
            "primary_rgb": primary,
            "secondary_rgb": secondary,
            "freq_x": 1.5 + (h_pos[6] % 5) * 0.5,
            "freq_y": 1.5 + (h_pos[7] % 5) * 0.5,
        }
