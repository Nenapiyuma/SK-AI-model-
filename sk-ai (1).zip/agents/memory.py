"""
AgentWorkingMemory: Short-term episodic working memory for multi-step agent execution.
User-controllable and clearable at any time.
"""

from typing import List, Dict, Any


class AgentWorkingMemory:
    def __init__(self, max_items: int = 50):
        self.max_items = max_items
        self.items: List[Dict[str, Any]] = []

    def add(self, role: str, summary: str, metadata: Dict[str, Any] | None = None) -> None:
        self.items.append({"role": role, "summary": summary, "metadata": metadata or {}})
        if len(self.items) > self.max_items:
            self.items = self.items[-self.max_items :]

    def get_recent(self, limit: int = 5) -> List[Dict[str, Any]]:
        return self.items[-limit:]

    def clear(self) -> None:
        self.items.clear()
