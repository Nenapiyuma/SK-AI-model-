"""
SK AI Document Understanding Subsystem (`documents/`).
Supports PDF, DOCX, XLSX, TXT, Markdown, CSV, and JSON.
"""

from .document_ai import SKDocumentAI

__all__ = ["SKDocumentAI"]
