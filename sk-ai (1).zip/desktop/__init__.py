"""
SK AI Desktop Application Architecture (`desktop/`).
Provides the local desktop host bridge for packaging SK AI as a standalone Windows/Linux desktop workbench.
"""

from .app import SKDesktopApp

__all__ = ["SKDesktopApp"]
