"""
SKDocumentAI: Local Multi-Format Document Parser, Table Analyzer, Summarizer & QA Engine.
Supports TXT, Markdown, CSV, JSON, DOCX (via XML zip extraction), XLSX (via sharedStrings XML), and PDF streams.
"""

import os
import re
import csv
import zipfile
import xml.etree.ElementTree as ET
from typing import Dict, Any, List, Optional


class SKDocumentAI:
    SUPPORTED_EXTENSIONS = [".txt", ".md", ".csv", ".json", ".docx", ".xlsx", ".pdf"]

    def extract_text(self, filepath: str) -> Dict[str, Any]:
        if not os.path.exists(filepath):
            return {"ok": False, "error": f"Document not found: {filepath}"}

        ext = os.path.splitext(filepath)[1].lower()
        text = ""
        tables: List[List[List[str]]] = []

        try:
            if ext in (".txt", ".md", ".json"):
                with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read()
            elif ext == ".csv":
                with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                    reader = list(csv.reader(f))
                    tables.append(reader)
                    text = "\n".join(", ".join(row) for row in reader)
            elif ext == ".docx" and zipfile.is_zipfile(filepath):
                with zipfile.ZipFile(filepath, "r") as zf:
                    if "word/document.xml" in zf.namelist():
                        xml_bytes = zf.read("word/document.xml")
                        root = ET.fromstring(xml_bytes)
                        paragraphs = [elem.text for elem in root.iter() if elem.text]
                        text = " ".join(paragraphs)
            elif ext == ".xlsx" and zipfile.is_zipfile(filepath):
                with zipfile.ZipFile(filepath, "r") as zf:
                    strings = []
                    if "xl/sharedStrings.xml" in zf.namelist():
                        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
                        strings = [elem.text for elem in root.iter() if elem.text]
                    text = " | ".join(strings)
            elif ext == ".pdf":
                with open(filepath, "rb") as f:
                    raw = f.read()
                # Extract printable ASCII/UTF-8 text runs inside PDF parenthetical literals
                matches = re.findall(rb"\(([^\(\)]{3,200})\)", raw)
                text = " ".join(m.decode("utf-8", errors="ignore") for m in matches)
                if not text.strip():
                    text = f"[PDF Binary Document: {os.path.basename(filepath)}, {len(raw)} bytes]"
            else:
                with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read()
        except Exception as e:
            return {"ok": False, "error": str(e)}

        words = text.split()
        sentences = [s.strip() for s in re.split(r"[.!?।]+", text) if s.strip()]
        summary = ". ".join(sentences[:3]) + ("." if sentences else "")

        return {
            "ok": True,
            "filepath": filepath,
            "format": ext or "txt",
            "char_count": len(text),
            "word_count": len(words),
            "sentence_count": len(sentences),
            "tables_extracted": len(tables),
            "summary": summary[:600],
            "text": text,
        }

    def answer_question(self, filepath: str, question: str) -> Dict[str, Any]:
        doc = self.extract_text(filepath)
        if not doc.get("ok"):
            return doc
        q_terms = {w.lower() for w in re.findall(r"\w+", question) if len(w) > 2}
        paragraphs = [p.strip() for p in doc["text"].split("\n") if p.strip()]
        scored = []
        for p in paragraphs:
            p_terms = {w.lower() for w in re.findall(r"\w+", p)}
            overlap = len(q_terms & p_terms)
            scored.append((overlap, p))
        scored.sort(key=lambda x: x[0], reverse=True)
        best = scored[0][1] if scored else doc["summary"]
        return {
            "ok": True,
            "question": question,
            "best_passage": best,
            "document_summary": doc["summary"],
        }
