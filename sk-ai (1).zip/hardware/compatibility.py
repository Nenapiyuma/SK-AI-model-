"""
Hardware Compatibility & Pre-Flight Model Load Checker.
Calculates whether the current machine's VRAM and system RAM can safely run a target model
and emits actionable warnings before attempting high-memory operations (e.g. SK-VIDEO, SK-LLM-Large).
"""

from typing import Dict, Any, List
from .detect import HardwareDetector


class HardwareCompatibilityChecker:
    @staticmethod
    def check_model_compatibility(
        model_name: str,
        required_ram_gb: float,
        required_vram_gb: float = 0.0,
        requires_gpu: bool = False,
        workspace_path: str = ".",
    ) -> Dict[str, Any]:
        hw = HardwareDetector.detect_all(workspace_path)
        avail_ram_gb = hw["memory"]["available_gb"]
        total_ram_gb = hw["memory"]["total_gb"]
        avail_vram_gb = hw["gpu"]["total_vram_gb"]
        has_gpu = hw["gpu"]["gpu_available"]

        warnings: List[str] = []
        can_run_gpu = has_gpu and (avail_vram_gb >= required_vram_gb)
        can_run_cpu = avail_ram_gb >= required_ram_gb

        if requires_gpu and not has_gpu:
            warnings.append(
                f"{model_name} recommends a dedicated CUDA GPU ({required_vram_gb} GB VRAM), "
                f"but no GPU was detected (current acceleration: {hw['gpu']['supported_acceleration']})."
            )
        elif required_vram_gb > 0 and avail_vram_gb < required_vram_gb:
            warnings.append(
                f"{model_name} requires {required_vram_gb} GB VRAM for full-speed GPU execution, "
                f"but detected VRAM is {avail_vram_gb} GB. Falling back to CPU/low-resolution mode if supported."
            )

        if avail_ram_gb < required_ram_gb:
            warnings.append(
                f"{model_name} requires {required_ram_gb} GB available system RAM, "
                f"but only {avail_ram_gb} GB (of {total_ram_gb} GB total) is currently available."
            )

        compatible = can_run_gpu or (not requires_gpu and can_run_cpu)
        recommended_execution = "GPU (CUDA)" if can_run_gpu else ("CPU Fallback" if can_run_cpu else "Insufficient Memory")

        return {
            "model_name": model_name,
            "compatible": compatible,
            "can_run_gpu": can_run_gpu,
            "can_run_cpu": can_run_cpu,
            "recommended_execution": recommended_execution,
            "required_ram_gb": required_ram_gb,
            "available_ram_gb": avail_ram_gb,
            "required_vram_gb": required_vram_gb,
            "available_vram_gb": avail_vram_gb,
            "warnings": warnings,
        }
